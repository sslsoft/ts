/**
 * Database connection setup
 */

const mongoose = require('mongoose');
const config = require('../../config');
const logger = require('../utils/logger');

// Connect to MongoDB
const connect = async () => {
  try {
    await mongoose.connect(config.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    logger.info('MongoDB connected successfully');
    return true;
  } catch (error) {
    logger.error('MongoDB connection error:', error);
    throw error;
  }
};

// Disconnect from MongoDB
const disconnect = async () => {
  try {
    await mongoose.disconnect();
    logger.info('MongoDB disconnected');
    return true;
  } catch (error) {
    logger.error('MongoDB disconnect error:', error);
    throw error;
  }
};

module.exports = {
  connect,
  disconnect
};