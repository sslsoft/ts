/**
 * User model for MongoDB
 */

const mongoose = require('mongoose');
const logger = require('../../utils/logger');

// User schema
const userSchema = new mongoose.Schema({
  userId: {
    type: Number,
    required: true,
    unique: true
  },
  username: {
    type: String,
    default: null
  },
  firstName: {
    type: String,
    default: null
  },
  lastName: {
    type: String,
    default: null
  },
  joinedAt: {
    type: Date,
    default: Date.now
  },
  lastActive: {
    type: Date,
    default: Date.now
  }
});

// Create model if it doesn't exist
const User = mongoose.models.User || mongoose.model('User', userSchema);

// Save user function
const saveUser = async (user) => {
  try {
    // Check if user exists
    const existingUser = await User.findOne({ userId: user.id });
    
    if (existingUser) {
      // Update last active timestamp
      await User.updateOne(
        { userId: user.id },
        { 
          $set: { 
            lastActive: new Date(),
            username: user.username || existingUser.username,
            firstName: user.first_name || existingUser.firstName,
            lastName: user.last_name || existingUser.lastName
          }
        }
      );
      return existingUser;
    }
    
    // Create new user
    const newUser = new User({
      userId: user.id,
      username: user.username,
      firstName: user.first_name,
      lastName: user.last_name
    });
    
    await newUser.save();
    logger.info(`New user saved: ${user.id} (${user.username || 'No username'})`);
    return newUser;
  } catch (error) {
    logger.error('Error saving user:', error);
    return null;
  }
};

module.exports = User;
module.exports.saveUser = saveUser;