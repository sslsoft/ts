/**
 * Bot initialization and configuration
 */

const { Telegraf, session } = require('telegraf');
const config = require('../config');
const logger = require('./utils/logger');

// Initialize bot with token
const bot = new Telegraf(config.BOT_TOKEN);

// Set up middleware
bot.use(session());

// Middleware to log all incoming messages
bot.use(async (ctx, next) => {
  const start = new Date();
  const user = ctx.from;
  
  if (user) {
    logger.info(`Message from ${user.first_name} (${user.id}): ${ctx.message?.text || '[Non-text message]'}`);
  }
  
  await next();
  
  const ms = new Date() - start;
  logger.debug(`Response time: ${ms}ms`);
});

// Middleware to save user to database if not exists
bot.use(async (ctx, next) => {
  if (ctx.from) {
    const { saveUser } = require('./database/models/user');
    await saveUser(ctx.from);
  }
  await next();
});

// Context middleware to check if download function is enabled
bot.use(async (ctx, next) => {
  ctx.state.config = {
    downloadEnabled: config.downloadEnabled
  };
  await next();
});

module.exports = { bot };