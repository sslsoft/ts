/**
 * User commands implementation
 */

const { Markup } = require('telegraf');
const downloadService = require('../services/downloadService');
const ffmpegService = require('../services/ffmpegService');
const systemInfo = require('../utils/systemInfo');
const config = require('../../config');
const logger = require('../utils/logger');
const User = require('../database/models/user');

const setUpCommandListeners = (bot) => {
  // Start command
  bot.start(async (ctx) => {
    const user = ctx.from;
    const message = `👋 Welcome to the All-in-One Video Downloader Bot, ${user.first_name}!
    
🎬 You can download videos from various websites by simply sending me the URL.
🎵 You can also extract audio from videos.

Use /help to see all available commands.`;

    await ctx.reply(message, {
      reply_markup: Markup.keyboard([
        ['📥 Send a video URL', '🎵 Extract audio'],
        ['⏱ Bot uptime', '💬 Contact admin']
      ]).resize()
    });
  });

  // Help command
  bot.help(async (ctx) => {
    const helpMessage = `🤖 *All-in-One Video Downloader Bot* 🤖

*Available Commands:*
/start - Start the bot
/help - Show this help message
/download [URL] - Download video from URL
/audio [URL] - Extract audio from video URL
/uptime - Check bot uptime
/feedback [message] - Send message to admin

You can also simply send a video URL to download it.`;

    await ctx.replyWithMarkdown(helpMessage);
  });

  // Handle direct URL messages
  bot.hears(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/, async (ctx) => {
    if (!ctx.state.config.downloadEnabled) {
      return await ctx.reply('⚠️ Video download function is currently disabled by the admin. Please try again later.');
    }

    const url = ctx.message.text;
    await handleVideoDownload(ctx, url);
  });

  // Download command
  bot.command('download', async (ctx) => {
    if (!ctx.state.config.downloadEnabled) {
      return await ctx.reply('⚠️ Video download function is currently disabled by the admin. Please try again later.');
    }

    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
      return await ctx.reply('⚠️ Please provide a URL. Example: /download https://example.com/video');
    }
    
    const url = args[1];
    await handleVideoDownload(ctx, url);
  });

  // Audio command
  bot.command('audio', async (ctx) => {
    if (!ctx.state.config.downloadEnabled) {
      return await ctx.reply('⚠️ Video download function is currently disabled by the admin. Please try again later.');
    }

    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
      return await ctx.reply('⚠️ Please provide a URL. Example: /audio https://example.com/video');
    }
    
    const url = args[1];
    await handleAudioExtraction(ctx, url);
  });

  // Uptime command
  bot.command('uptime', async (ctx) => {
    const uptimeInfo = systemInfo.getUptimeInfo();
    await ctx.reply(`⏱ *Bot Uptime Information*\n\n${uptimeInfo}`, {
      parse_mode: 'Markdown'
    });
  });

  // Feedback command
  bot.command('feedback', async (ctx) => {
    const args = ctx.message.text.split(' ');
    args.shift(); // Remove the command
    
    const message = args.join(' ');
    if (!message) {
      return await ctx.reply('⚠️ Please provide a message. Example: /feedback Your bot is awesome!');
    }
    
    // Forward message to all admins
    for (const adminId of config.ADMIN_IDS) {
      try {
        await bot.telegram.sendMessage(adminId, 
          `📨 *New feedback from user*\n\n` +
          `👤 *User:* ${ctx.from.first_name} (ID: ${ctx.from.id})\n` +
          `💬 *Message:* ${message}`, {
            parse_mode: 'Markdown'
          });
      } catch (error) {
        logger.error(`Failed to send feedback to admin ${adminId}:`, error);
      }
    }
    
    await ctx.reply('✅ Your message has been sent to the admin. Thank you for your feedback!');
  });

  // Button handlers
  bot.hears('📥 Send a video URL', (ctx) => {
    ctx.reply('Please send me the URL of the video you want to download.');
  });

  bot.hears('🎵 Extract audio', (ctx) => {
    ctx.reply('Please send me the URL of the video from which you want to extract audio.');
  });

  bot.hears('⏱ Bot uptime', async (ctx) => {
    const uptimeInfo = systemInfo.getUptimeInfo();
    await ctx.reply(`⏱ *Bot Uptime Information*\n\n${uptimeInfo}`, {
      parse_mode: 'Markdown'
    });
  });

  bot.hears('💬 Contact admin', (ctx) => {
    ctx.reply('Please use the /feedback command followed by your message to contact the admin.\n\nExample: /feedback Hello admin, I have a question.');
  });
};

// Helper functions
async function handleVideoDownload(ctx, url) {
  const statusMessage = await ctx.reply('🔍 Processing your request...');
  
  try {
    await ctx.replyWithChatAction('upload_video');
    
    const result = await downloadService.downloadVideo(url);
    
    if (!result.success) {
      await ctx.telegram.editMessageText(
        ctx.chat.id, 
        statusMessage.message_id, 
        null, 
        `❌ Failed to download video: ${result.error}`
      );
      return;
    }
    
    await ctx.telegram.editMessageText(
      ctx.chat.id, 
      statusMessage.message_id, 
      null, 
      '✅ Download successful! Sending video...'
    );
    
    // Send video file
    await ctx.replyWithVideo(
      { source: result.filePath },
      { 
        caption: `Title: ${result.title || 'Video'}\nRequested by: @${ctx.from.username || ctx.from.id}` 
      }
    );
    
    // Clean up temporary files
    downloadService.cleanupFiles(result.filePath);
    
  } catch (error) {
    logger.error('Video download error:', error);
    await ctx.telegram.editMessageText(
      ctx.chat.id, 
      statusMessage.message_id, 
      null, 
      `❌ An error occurred: ${error.message}`
    );
  }
}

async function handleAudioExtraction(ctx, url) {
  const statusMessage = await ctx.reply('🔍 Processing your request...');
  
  try {
    await ctx.replyWithChatAction('upload_audio');
    
    const videoResult = await downloadService.downloadVideo(url);
    
    if (!videoResult.success) {
      await ctx.telegram.editMessageText(
        ctx.chat.id, 
        statusMessage.message_id, 
        null, 
        `❌ Failed to download video: ${videoResult.error}`
      );
      return;
    }
    
    await ctx.telegram.editMessageText(
      ctx.chat.id, 
      statusMessage.message_id, 
      null, 
      '🎵 Converting video to audio...'
    );
    
    const audioResult = await ffmpegService.convertToMp3(videoResult.filePath);
    
    if (!audioResult.success) {
      await ctx.telegram.editMessageText(
        ctx.chat.id, 
        statusMessage.message_id, 
        null, 
        `❌ Failed to convert to audio: ${audioResult.error}`
      );
      return;
    }
    
    await ctx.telegram.editMessageText(
      ctx.chat.id, 
      statusMessage.message_id, 
      null, 
      '✅ Conversion successful! Sending audio...'
    );
    
    // Send audio file
    await ctx.replyWithAudio(
      { source: audioResult.filePath },
      { 
        title: videoResult.title || 'Audio',
        caption: `Extracted from: ${url}\nRequested by: @${ctx.from.username || ctx.from.id}`
      }
    );
    
    // Clean up temporary files
    downloadService.cleanupFiles(videoResult.filePath);
    downloadService.cleanupFiles(audioResult.filePath);
    
  } catch (error) {
    logger.error('Audio extraction error:', error);
    await ctx.telegram.editMessageText(
      ctx.chat.id, 
      statusMessage.message_id, 
      null, 
      `❌ An error occurred: ${error.message}`
    );
  }
}

module.exports = { setUpCommandListeners };