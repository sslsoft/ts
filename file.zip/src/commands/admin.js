/**
 * Admin commands implementation
 */

const { Markup } = require('telegraf');
const User = require('../database/models/user');
const systemInfo = require('../utils/systemInfo');
const config = require('../../config');
const logger = require('../utils/logger');
const apiService = require('../services/apiService');

// Check if user is admin
const isAdmin = (ctx) => {
  return config.ADMIN_IDS.includes(ctx.from.id.toString());
};

// Admin middleware
const adminMiddleware = (ctx, next) => {
  if (isAdmin(ctx)) {
    return next();
  }
  return ctx.reply('⛔ This command is for admins only.');
};

const setUpAdminCommandListeners = (bot) => {
  // Admin panel
  bot.command('admin', adminMiddleware, async (ctx) => {
    await ctx.reply('🔐 *Admin Panel*', {
      parse_mode: 'Markdown',
      ...Markup.keyboard([
        ['📊 User Stats', '📡 Server Info'],
        ['📣 Broadcast', '🔄 Toggle Downloads'],
        ['✉️ Message User', '🔑 Update API Key'],
        ['🔙 Exit Admin Panel']
      ]).resize()
    });
  });

  // Broadcast message to all users
  bot.command('broadcast', adminMiddleware, async (ctx) => {
    const args = ctx.message.text.split(' ');
    args.shift(); // Remove the command
    
    const message = args.join(' ');
    if (!message) {
      return await ctx.reply('⚠️ Please provide a message to broadcast. Example: /broadcast Important announcement!');
    }
    
    const statusMsg = await ctx.reply('📣 Broadcasting message...');
    
    try {
      const users = await User.find({});
      let successCount = 0;
      let failCount = 0;
      
      for (const user of users) {
        try {
          await bot.telegram.sendMessage(user.userId, 
            `📣 *Broadcast Message from Admin*\n\n${message}`, {
              parse_mode: 'Markdown'
            });
          successCount++;
        } catch (error) {
          logger.error(`Failed to send broadcast to user ${user.userId}:`, error);
          failCount++;
        }
      }
      
      await ctx.telegram.editMessageText(
        ctx.chat.id,
        statusMsg.message_id,
        null,
        `✅ Broadcast completed!\n\n` +
        `📊 *Statistics*:\n` +
        `- Total users: ${users.length}\n` +
        `- Successfully sent: ${successCount}\n` +
        `- Failed: ${failCount}`,
        { parse_mode: 'Markdown' }
      );
    } catch (error) {
      logger.error('Broadcast error:', error);
      await ctx.telegram.editMessageText(
        ctx.chat.id,
        statusMsg.message_id,
        null,
        `❌ An error occurred while broadcasting: ${error.message}`
      );
    }
  });

  // Get user statistics
  bot.command('stats', adminMiddleware, async (ctx) => {
    try {
      const totalUsers = await User.countDocuments();
      const last24hUsers = await User.countDocuments({
        lastActive: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) }
      });
      const last7dUsers = await User.countDocuments({
        lastActive: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
      });
      
      await ctx.replyWithMarkdown(
        `📊 *User Statistics*\n\n` +
        `👥 Total users: ${totalUsers}\n` +
        `👤 Active users (24h): ${last24hUsers}\n` +
        `👥 Active users (7d): ${last7dUsers}\n\n` +
        `🔄 Download function: ${config.downloadEnabled ? '✅ Enabled' : '❌ Disabled'}`
      );
    } catch (error) {
      logger.error('Stats command error:', error);
      await ctx.reply(`❌ An error occurred: ${error.message}`);
    }
  });

  // Toggle download function
  bot.command('toggle', adminMiddleware, async (ctx) => {
    try {
      config.downloadEnabled = !config.downloadEnabled;
      await ctx.reply(`🔄 Download function is now ${config.downloadEnabled ? '✅ Enabled' : '❌ Disabled'}`);
      logger.info(`Admin ${ctx.from.id} ${config.downloadEnabled ? 'enabled' : 'disabled'} download function`);
    } catch (error) {
      logger.error('Toggle command error:', error);
      await ctx.reply(`❌ An error occurred: ${error.message}`);
    }
  });

  // Send message to specific user
  bot.command('message', adminMiddleware, async (ctx) => {
    const args = ctx.message.text.split(' ');
    args.shift(); // Remove the command
    
    if (args.length < 2) {
      return await ctx.reply('⚠️ Please provide a user ID and message. Example: /message 123456789 Hello user!');
    }
    
    const userId = args[0];
    args.shift(); // Remove the user ID
    const message = args.join(' ');
    
    try {
      await bot.telegram.sendMessage(userId, 
        `📨 *Message from Admin*\n\n${message}`, {
          parse_mode: 'Markdown'
        });
      
      await ctx.reply(`✅ Message sent to user ${userId}`);
    } catch (error) {
      logger.error(`Failed to send message to user ${userId}:`, error);
      await ctx.reply(`❌ Failed to send message: ${error.message}`);
    }
  });

  // Get server information
  bot.command('server', adminMiddleware, async (ctx) => {
    try {
      const serverInfo = await systemInfo.getServerInfo();
      
      await ctx.replyWithMarkdown(
        `🖥️ *Server Information*\n\n` +
        `${serverInfo}\n\n` +
        `⏱ *Bot Uptime*\n${systemInfo.getUptimeInfo()}`
      );
    } catch (error) {
      logger.error('Server command error:', error);
      await ctx.reply(`❌ An error occurred: ${error.message}`);
    }
  });

  // Update API key
  bot.command('updateapi', adminMiddleware, async (ctx) => {
    const args = ctx.message.text.split(' ');
    
    if (args.length < 2) {
      return await ctx.reply('⚠️ Please provide a new API key. Example: /updateapi your_new_api_key');
    }
    
    const newApiKey = args[1];
    
    try {
      // Test the new API key
      const testResult = await apiService.testApiKey(newApiKey);
      
      if (testResult.success) {
        // Update the API key in config
        config.API_KEY = newApiKey;
        
        // You would typically save this to a database or environment file here
        
        await ctx.reply('✅ API key updated successfully!');
        logger.info(`Admin ${ctx.from.id} updated API key`);
      } else {
        await ctx.reply(`❌ API key test failed: ${testResult.error}`);
      }
    } catch (error) {
      logger.error('Update API key error:', error);
      await ctx.reply(`❌ An error occurred: ${error.message}`);
    }
  });

  // Admin button handlers
  bot.hears('📊 User Stats', adminMiddleware, async (ctx) => {
    try {
      const totalUsers = await User.countDocuments();
      const last24hUsers = await User.countDocuments({
        lastActive: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) }
      });
      const last7dUsers = await User.countDocuments({
        lastActive: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
      });
      
      await ctx.replyWithMarkdown(
        `📊 *User Statistics*\n\n` +
        `👥 Total users: ${totalUsers}\n` +
        `👤 Active users (24h): ${last24hUsers}\n` +
        `👥 Active users (7d): ${last7dUsers}\n\n` +
        `🔄 Download function: ${config.downloadEnabled ? '✅ Enabled' : '❌ Disabled'}`
      );
    } catch (error) {
      logger.error('Stats command error:', error);
      await ctx.reply(`❌ An error occurred: ${error.message}`);
    }
  });

  bot.hears('📡 Server Info', adminMiddleware, async (ctx) => {
    try {
      const serverInfo = await systemInfo.getServerInfo();
      
      await ctx.replyWithMarkdown(
        `🖥️ *Server Information*\n\n` +
        `${serverInfo}\n\n` +
        `⏱ *Bot Uptime*\n${systemInfo.getUptimeInfo()}`
      );
    } catch (error) {
      logger.error('Server info error:', error);
      await ctx.reply(`❌ An error occurred: ${error.message}`);
    }
  });

  bot.hears('📣 Broadcast', adminMiddleware, (ctx) => {
    ctx.reply('Please use the /broadcast command followed by your message to send a broadcast to all users.\n\nExample: /broadcast Important announcement!');
  });

  bot.hears('🔄 Toggle Downloads', adminMiddleware, async (ctx) => {
    try {
      config.downloadEnabled = !config.downloadEnabled;
      await ctx.reply(`🔄 Download function is now ${config.downloadEnabled ? '✅ Enabled' : '❌ Disabled'}`);
      logger.info(`Admin ${ctx.from.id} ${config.downloadEnabled ? 'enabled' : 'disabled'} download function`);
    } catch (error) {
      logger.error('Toggle downloads error:', error);
      await ctx.reply(`❌ An error occurred: ${error.message}`);
    }
  });

  bot.hears('✉️ Message User', adminMiddleware, (ctx) => {
    ctx.reply('Please use the /message command followed by the user ID and your message to send a message to a specific user.\n\nExample: /message 123456789 Hello user!');
  });

  bot.hears('🔑 Update API Key', adminMiddleware, (ctx) => {
    ctx.reply('Please use the /updateapi command followed by the new API key to update the API key.\n\nExample: /updateapi your_new_api_key');
  });

  bot.hears('🔙 Exit Admin Panel', adminMiddleware, async (ctx) => {
    await ctx.reply('✅ Exited admin panel.', {
      reply_markup: Markup.keyboard([
        ['📥 Send a video URL', '🎵 Extract audio'],
        ['⏱ Bot uptime', '💬 Contact admin']
      ]).resize()
    });
  });
};

module.exports = { setUpAdminCommandListeners, adminMiddleware, isAdmin };