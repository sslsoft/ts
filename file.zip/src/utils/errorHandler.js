/**
 * Error handling utility
 */

const logger = require('./logger');
const config = require('../../config');

// Handle bot errors
const handleBotError = (error) => {
  logger.error('Bot error:', error);
  
  // Notify admins about critical errors
  if (isCriticalError(error)) {
    notifyAdminsAboutError(error);
  }
  
  return error;
};

// Handle API errors
const handleApiError = (error, context = {}) => {
  logger.error('API error:', error, { context });
  
  // Notify admins about API errors
  if (isApiKeyError(error)) {
    notifyAdminsAboutApiKeyError(error);
  }
  
  return error;
};

// Notify admins about errors
const notifyAdminsAboutError = async (error) => {
  const { bot } = require('../bot');
  
  for (const adminId of config.ADMIN_IDS) {
    try {
      await bot.telegram.sendMessage(adminId, 
        `⚠️ *Critical Error Alert*\n\n` +
        `The following error occurred:\n` +
        `\`\`\`\n${error.message}\n\`\`\``, {
          parse_mode: 'Markdown'
        });
    } catch (notifyError) {
      logger.error(`Failed to notify admin ${adminId} about error:`, notifyError);
    }
  }
};

// Notify admins about API key errors
const notifyAdminsAboutApiKeyError = async (error) => {
  const { bot } = require('../bot');
  
  for (const adminId of config.ADMIN_IDS) {
    try {
      await bot.telegram.sendMessage(adminId, 
        `⚠️ *API Key Error Alert*\n\n` +
        `The following error occurred with the API key:\n` +
        `\`\`\`\n${error.message}\n\`\`\`\n\n` +
        `Please update the API key using the /updateapi command.`, {
          parse_mode: 'Markdown'
        });
    } catch (notifyError) {
      logger.error(`Failed to notify admin ${adminId} about API key error:`, notifyError);
    }
  }
};

// Check if error is critical
const isCriticalError = (error) => {
  const criticalErrorMessages = [
    'ETELEGRAM',
    'EFATAL',
    'socket hang up',
    'read ECONNRESET',
    'connect ETIMEDOUT'
  ];
  
  return criticalErrorMessages.some(msg => 
    error.message && error.message.includes(msg)
  );
};

// Check if error is related to API key
const isApiKeyError = (error) => {
  const apiKeyErrorMessages = [
    'api key',
    'apikey',
    'authorization',
    'unauthorized',
    '401',
    'forbidden',
    '403'
  ];
  
  return apiKeyErrorMessages.some(msg => 
    error.message && error.message.toLowerCase().includes(msg)
  );
};

module.exports = {
  handleBotError,
  handleApiError,
  notifyAdminsAboutError
};