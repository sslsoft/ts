/**
 * System information utility
 */

const os = require('os');
const fs = require('fs');
const path = require('path');
const logger = require('./logger');

// Get uptime information
const getUptimeInfo = () => {
  try {
    const botStartTime = global.BOT_START_TIME || new Date();
    const uptime = new Date() - botStartTime;
    
    const days = Math.floor(uptime / (1000 * 60 * 60 * 24));
    const hours = Math.floor((uptime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((uptime % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((uptime % (1000 * 60)) / 1000);
    
    return `🕒 Bot started: ${botStartTime.toISOString()}\n` +
           `⏱ Uptime: ${days}d ${hours}h ${minutes}m ${seconds}s`;
  } catch (error) {
    logger.error('Error getting uptime info:', error);
    return 'Unable to retrieve uptime information';
  }
};

// Get server information
const getServerInfo = async () => {
  try {
    // CPU info
    const cpus = os.cpus();
    const cpuModel = cpus.length > 0 ? cpus[0].model : 'Unknown CPU';
    const cpuCores = cpus.length;
    const cpuUsage = await getCpuUsage();
    
    // Memory info
    const totalMemory = (os.totalmem() / (1024 * 1024 * 1024)).toFixed(2); // GB
    const freeMemory = (os.freemem() / (1024 * 1024 * 1024)).toFixed(2); // GB
    const usedMemory = (totalMemory - freeMemory).toFixed(2); // GB
    const memoryUsage = ((usedMemory / totalMemory) * 100).toFixed(2); // %
    
    // Disk info
    const diskInfo = await getDiskInfo();
    
    // OS info
    const platform = os.platform();
    const release = os.release();
    const hostname = os.hostname();
    
    // Process info
    const processUptime = Math.floor(process.uptime());
    const uptimeDays = Math.floor(processUptime / (60 * 60 * 24));
    const uptimeHours = Math.floor((processUptime % (60 * 60 * 24)) / (60 * 60));
    const uptimeMinutes = Math.floor((processUptime % (60 * 60)) / 60);
    
    return `🖥️ *System Information*\n` +
           `Platform: ${platform} ${release}\n` +
           `Hostname: ${hostname}\n\n` +
           
           `📊 *CPU*\n` +
           `Model: ${cpuModel}\n` +
           `Cores: ${cpuCores}\n` +
           `Usage: ${cpuUsage}%\n\n` +
           
           `🧠 *Memory*\n` +
           `Total: ${totalMemory} GB\n` +
           `Used: ${usedMemory} GB (${memoryUsage}%)\n` +
           `Free: ${freeMemory} GB\n\n` +
           
           `💾 *Disk*\n` +
           `Total: ${diskInfo.total} GB\n` +
           `Used: ${diskInfo.used} GB (${diskInfo.usedPercent}%)\n` +
           `Free: ${diskInfo.free} GB\n\n` +
           
           `⏱ *Server Uptime*\n` +
           `${uptimeDays}d ${uptimeHours}h ${uptimeMinutes}m`;
  } catch (error) {
    logger.error('Error getting server info:', error);
    return 'Unable to retrieve server information';
  }
};

// Get CPU usage
const getCpuUsage = () => {
  return new Promise((resolve) => {
    // Get initial measurements
    const initialCpus = os.cpus();
    
    // Wait for 100ms
    setTimeout(() => {
      // Get measurements after 100ms
      const currentCpus = os.cpus();
      
      let totalIdle = 0;
      let totalTick = 0;
      
      // Calculate the difference
      for (let i = 0; i < currentCpus.length; i++) {
        const initialCpu = initialCpus[i];
        const currentCpu = currentCpus[i];
        
        // Calculate total difference
        for (const type in currentCpu.times) {
          totalTick += (currentCpu.times[type] - initialCpu.times[type]);
        }
        
        // Calculate idle difference
        totalIdle += (currentCpu.times.idle - initialCpu.times.idle);
      }
      
      // Calculate CPU usage percentage
      const usagePercent = 100 - ((totalIdle / totalTick) * 100);
      resolve(usagePercent.toFixed(2));
    }, 100);
  });
};

// Get disk information
const getDiskInfo = () => {
  return new Promise((resolve, reject) => {
    try {
      // For simplicity, we'll check the disk where the bot is running
      const rootDirectory = path.parse(os.homedir()).root;
      
      // On Unix-like systems, we can use df command
      if (os.platform() !== 'win32') {
        const { execSync } = require('child_process');
        const output = execSync(`df -k ${rootDirectory}`).toString();
        const lines = output.trim().split('\n');
        
        if (lines.length >= 2) {
          const stats = lines[1].split(/\s+/);
          
          // Parse disk info (kB to GB)
          const total = (parseInt(stats[1]) / (1024 * 1024)).toFixed(2);
          const used = (parseInt(stats[2]) / (1024 * 1024)).toFixed(2);
          const free = (parseInt(stats[3]) / (1024 * 1024)).toFixed(2);
          const usedPercent = stats[4].replace('%', '');
          
          resolve({ total, used, free, usedPercent });
        } else {
          resolve({ total: 'N/A', used: 'N/A', free: 'N/A', usedPercent: 'N/A' });
        }
      } else {
        // On Windows, we can use wmic command
        const { execSync } = require('child_process');
        const output = execSync('wmic logicaldisk get size,freespace,caption').toString();
        const lines = output.trim().split('\n');
        
        // Find the root drive
        for (let i = 1; i < lines.length; i++) {
          const parts = lines[i].trim().split(/\s+/);
          
          if (parts.length === 3 && parts[0] === rootDirectory.charAt(0) + ':') {
            const freeSpace = parseInt(parts[1]);
            const totalSize = parseInt(parts[2]);
            const usedSpace = totalSize - freeSpace;
            
            // Convert bytes to GB
            const total = (totalSize / (1024 * 1024 * 1024)).toFixed(2);
            const free = (freeSpace / (1024 * 1024 * 1024)).toFixed(2);
            const used = (usedSpace / (1024 * 1024 * 1024)).toFixed(2);
            const usedPercent = ((usedSpace / totalSize) * 100).toFixed(2);
            
            resolve({ total, used, free, usedPercent });
            return;
          }
        }
        
        resolve({ total: 'N/A', used: 'N/A', free: 'N/A', usedPercent: 'N/A' });
      }
    } catch (error) {
      logger.error('Error getting disk info:', error);
      resolve({ total: 'N/A', used: 'N/A', free: 'N/A', usedPercent: 'N/A' });
    }
  });
};

module.exports = {
  getUptimeInfo,
  getServerInfo
};