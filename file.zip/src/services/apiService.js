/**
 * API service for video downloads
 */

const axios = require('axios');
const config = require('../../config');
const logger = require('../utils/logger');

// Build API URL with API key
const buildApiUrl = (videoUrl, apiKey = config.API_KEY) => {
  return `https://ai.aioserver.news/ap/api/?api_key=${apiKey}&url=${encodeURIComponent(videoUrl)}`;
};

// Get video info from API
const getVideoInfo = async (videoUrl) => {
  try {
    const apiUrl = buildApiUrl(videoUrl);
    const response = await axios.get(apiUrl);
    
    if (response.status !== 200) {
      logger.error(`API request failed with status ${response.status}`);
      return { success: false, error: `API request failed with status ${response.status}` };
    }
    
    const data = response.data;
    
    if (data.error) {
      logger.error(`API returned error: ${data.error}`);
      
      // Notify admins if API key error
      if (data.error.toLowerCase().includes('api key')) {
        notifyAdminsAboutApiKeyError(data.error);
      }
      
      return { success: false, error: data.error };
    }
    
    return { success: true, data };
  } catch (error) {
    logger.error('Video info API error:', error);
    return { success: false, error: error.message };
  }
};

// Test API key
const testApiKey = async (apiKey) => {
  try {
    // Use a known working video URL for testing
    const testUrl = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ';
    const apiUrl = buildApiUrl(testUrl, apiKey);
    
    const response = await axios.get(apiUrl);
    
    if (response.status !== 200) {
      return { success: false, error: `API request failed with status ${response.status}` };
    }
    
    const data = response.data;
    
    if (data.error) {
      return { success: false, error: data.error };
    }
    
    return { success: true };
  } catch (error) {
    logger.error('API key test error:', error);
    return { success: false, error: error.message };
  }
};

// Notify admins about API key errors
const notifyAdminsAboutApiKeyError = async (errorMessage) => {
  const { bot } = require('../bot');
  
  for (const adminId of config.ADMIN_IDS) {
    try {
      await bot.telegram.sendMessage(adminId, 
        `⚠️ *API Key Error Alert*\n\n` +
        `The following error occurred with the API key:\n` +
        `\`\`\`\n${errorMessage}\n\`\`\`\n\n` +
        `Please update the API key using the /updateapi command.`, {
          parse_mode: 'Markdown'
        });
    } catch (error) {
      logger.error(`Failed to notify admin ${adminId} about API key error:`, error);
    }
  }
};

module.exports = {
  getVideoInfo,
  testApiKey
};