/**
 * FFmpeg service for audio extraction
 */

const ffmpeg = require('fluent-ffmpeg');
const path = require('path');
const fs = require('fs');
const logger = require('../utils/logger');

// Create temporary directory if it doesn't exist
const tempDir = path.join(__dirname, '../../temp');
if (!fs.existsSync(tempDir)) {
  fs.mkdirSync(tempDir, { recursive: true });
}

// Convert video to MP3
const convertToMp3 = (videoPath) => {
  return new Promise((resolve, reject) => {
    try {
      // Generate output file path
      const outputFileName = path.basename(videoPath, path.extname(videoPath)) + '.mp3';
      const outputPath = path.join(tempDir, outputFileName);
      
      logger.info(`Converting ${videoPath} to MP3 at ${outputPath}`);
      
      ffmpeg(videoPath)
        .noVideo()
        .audioCodec('libmp3lame')
        .audioBitrate('128k')
        .output(outputPath)
        .on('end', () => {
          logger.info(`MP3 conversion completed: ${outputPath}`);
          resolve({
            success: true,
            filePath: outputPath,
            format: 'mp3'
          });
        })
        .on('error', (err) => {
          logger.error(`MP3 conversion error: ${err.message}`);
          reject({ success: false, error: err.message });
        })
        .run();
    } catch (error) {
      logger.error('FFmpeg service error:', error);
      reject({ success: false, error: error.message });
    }
  });
};

module.exports = {
  convertToMp3
};