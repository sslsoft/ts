/**
 * Video download service
 */

const axios = require('axios');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const apiService = require('./apiService');
const logger = require('../utils/logger');

// Create temporary directory if it doesn't exist
const tempDir = path.join(__dirname, '../../temp');
if (!fs.existsSync(tempDir)) {
  fs.mkdirSync(tempDir, { recursive: true });
}

// Download video function
const downloadVideo = async (url) => {
  try {
    // Get video info from API
    const videoInfo = await apiService.getVideoInfo(url);
    
    if (!videoInfo.success) {
      return videoInfo; // Return error from API
    }
    
    const { data } = videoInfo;
    
    // Generate a random file name
    const randomName = crypto.randomBytes(16).toString('hex');
    const fileExt = getFileExtension(data.url) || 'mp4';
    const fileName = `${randomName}.${fileExt}`;
    const filePath = path.join(tempDir, fileName);
    
    // Download the video file
    const writer = fs.createWriteStream(filePath);
    logger.info(`Downloading video from ${data.url} to ${filePath}`);
    
    const response = await axios({
      url: data.url,
      method: 'GET',
      responseType: 'stream'
    });
    
    response.data.pipe(writer);
    
    return new Promise((resolve, reject) => {
      writer.on('finish', () => {
        logger.info(`Video download completed: ${filePath}`);
        resolve({
          success: true,
          filePath,
          title: data.title,
          format: fileExt
        });
      });
      
      writer.on('error', (err) => {
        logger.error(`Video download error: ${err.message}`);
        reject({ success: false, error: err.message });
      });
    });
  } catch (error) {
    logger.error('Download service error:', error);
    return { success: false, error: error.message };
  }
};

// Clean up temporary files
const cleanupFiles = (filePath) => {
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      logger.info(`Deleted temporary file: ${filePath}`);
    }
  } catch (error) {
    logger.error(`Error deleting file ${filePath}:`, error);
  }
};

// Helper function to get file extension from URL
const getFileExtension = (url) => {
  try {
    const urlObj = new URL(url);
    const pathname = urlObj.pathname;
    const extension = path.extname(pathname).toLowerCase();
    
    if (extension) {
      return extension.substring(1); // Remove the dot
    }
    
    // Default to mp4 if no extension found
    return 'mp4';
  } catch (error) {
    logger.error('Error getting file extension:', error);
    return 'mp4'; // Default to mp4
  }
};

module.exports = {
  downloadVideo,
  cleanupFiles
};