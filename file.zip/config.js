/**
 * Configuration file
 */

require('dotenv').config();

module.exports = {
  // Bot token from environment variables
  BOT_TOKEN: process.env.BOT_TOKEN,
  
  // MongoDB connection string
  MONGODB_URI: process.env.MONGODB_URI || 'mongodb+srv://allmaster:allinoneseXASWA@221@clustervideo.lht9ruf.mongodb.net/?retryWrites=true&w=majority&appName=Clustervideo',
  
  // Admin IDs (comma-separated list in .env)
  ADMIN_IDS: (process.env.ADMIN_IDS || '').split(',').filter(Boolean),
  
  // API key for video download service
  API_KEY: process.env.API_KEY || '91f5fd40338ce7444e7870922617213952c89122980594fd28b19f80b2a6d9f8',
  
  // Feature flags
  downloadEnabled: true,
  
  // Paths
  tempDir: './temp',
  logsDir: './logs'
};