/**
 * All-in-One Video Downloader Telegram Bot
 * Main entry point for the application
 */

require('dotenv').config();
const { bot } = require('./src/bot');
const database = require('./src/database/connection');
const logger = require('./src/utils/logger');
const { setUpCommandListeners } = require('./src/commands/user');
const { setUpAdminCommandListeners } = require('./src/commands/admin');
const errorHandler = require('./src/utils/errorHandler');

// Connect to database
database.connect()
  .then(() => {
    logger.info('Connected to MongoDB');
    
    // Set up command listeners
    setUpCommandListeners(bot);
    setUpAdminCommandListeners(bot);
    
    // Set up global error handler
    bot.catch((err) => {
      errorHandler.handleBotError(err);
    });
    
    // Start the bot
    bot.launch()
      .then(() => {
        const startTime = new Date();
        global.BOT_START_TIME = startTime;
        logger.info(`Bot started at ${startTime.toISOString()}`);
      })
      .catch((err) => {
        logger.error('Failed to start bot:', err);
        process.exit(1);
      });
    
    // Enable graceful stop
    process.once('SIGINT', () => bot.stop('SIGINT'));
    process.once('SIGTERM', () => bot.stop('SIGTERM'));
  })
  .catch((err) => {
    logger.error('Database connection error:', err);
    process.exit(1);
  });