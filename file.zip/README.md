# All-in-One Video Downloader Telegram Bot

A powerful Telegram bot that lets users download videos and audio from various websites simply by sending the URL.

## Features

### User Features
- Download videos by simply sending a link
- Extract audio (MP3) from videos
- Check bot uptime
- Send messages to admin

### Admin Features
- Broadcast messages to all users
- View user statistics (total users, active users)
- Enable/disable video download function
- Send messages to specific users
- View detailed server statistics
- Update API key through admin panel
- Receive notifications about API errors

## Setup and Installation

### Prerequisites
- Node.js (v14 or newer)
- MongoDB
- FFmpeg installed on your server
- A Telegram Bot Token (get from [@BotFather](https://t.me/BotFather))

### Installation Steps

1. Clone this repository:
```bash
git clone https://github.com/yourusername/telegram-video-downloader-bot.git
cd telegram-video-downloader-bot
```

2. Install dependencies:
```bash
npm install
```

3. Create a `.env` file by copying the example:
```bash
cp .env.example .env
```

4. Edit the `.env` file with your configuration:
```
BOT_TOKEN=your_telegram_bot_token
MONGODB_URI=your_mongodb_connection_string
ADMIN_IDS=comma,separated,admin,ids
API_KEY=your_video_api_key
```

5. Start the bot:
```bash
npm start
```

For production use, it's recommended to use a process manager like PM2:
```bash
npm install -g pm2
pm2 start index.js --name video-downloader-bot
```

## Bot Commands

### User Commands
- `/start` - Start the bot and get welcome message
- `/help` - Show help message with available commands
- `/download [URL]` - Download video from URL
- `/audio [URL]` - Extract audio from video URL
- `/uptime` - Check bot uptime
- `/feedback [message]` - Send message to admin

### Admin Commands
- `/admin` - Access admin panel
- `/broadcast [message]` - Send message to all users
- `/stats` - View user statistics
- `/toggle` - Enable/disable video download function
- `/message [userID] [message]` - Send message to specific user
- `/server` - View server details
- `/updateapi [new_api_key]` - Update the API key

## License

MIT