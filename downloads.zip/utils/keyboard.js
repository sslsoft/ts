// Function to get keyboard markup based on user role
function getKeyboard(user) {
  if (!user) {
    return getDefaultKeyboard();
  }
  
  if (user.isAdmin) {
    return getAdminKeyboard();
  } else if (user.isPremium) {
    return getPremiumKeyboard();
  } else {
    return getDefaultKeyboard();
  }
}

// Default keyboard for regular users
function getDefaultKeyboard() {
  return {
    keyboard: [
      [{ text: '📋 Help' }, { text: '👤 Profile' }],
      [{ text: '📱 Premium' }, { text: '📞 Contact Admin' }]
    ],
    resize_keyboard: true
  };
}

// Premium user keyboard
function getPremiumKeyboard() {
  return {
    keyboard: [
      [{ text: '📋 Help' }, { text: '👤 Profile' }, { text: '📚 History' }],
      [{ text: '⭐ Premium Status' }, { text: '📞 Contact Admin' }]
    ],
    resize_keyboard: true
  };
}

// Admin keyboard
function getAdminKeyboard() {
  return {
    keyboard: [
      [{ text: '📋 Help' }, { text: '👤 Profile' }, { text: '📚 History' }],
      [{ text: '⚙️ Admin Panel' }, { text: '📊 Statistics' }, { text: '📢 Broadcast' }]
    ],
    resize_keyboard: true
  };
}

module.exports = {
  getKeyboard
};