// Function to extract URLs from text
function extractUrlFromText(text) {
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const matches = text.match(urlRegex);
  
  if (matches && matches.length > 0) {
    return matches[0]; // Return the first URL found
  }
  
  return null;
}

// Function to get platform name from URL
function getPlatformFromUrl(url) {
  try {
    const hostname = new URL(url).hostname.toLowerCase();
    
    if (hostname.includes('youtube') || hostname.includes('youtu.be')) {
      return 'YouTube';
    } else if (hostname.includes('facebook') || hostname.includes('fb.watch')) {
      return 'Facebook';
    } else if (hostname.includes('instagram')) {
      return 'Instagram';
    } else if (hostname.includes('tiktok')) {
      return 'TikTok';
    } else if (hostname.includes('twitter') || hostname.includes('x.com')) {
      return 'Twitter';
    } else if (hostname.includes('linkedin')) {
      return 'LinkedIn';
    } else if (hostname.includes('vimeo')) {
      return 'Vimeo';
    } else if (hostname.includes('dailymotion')) {
      return 'Dailymotion';
    } else if (hostname.includes('reddit')) {
      return 'Reddit';
    } else if (hostname.includes('twitch')) {
      return 'Twitch';
    } else if (hostname.includes('pinterest')) {
      return 'Pinterest';
    } else {
      return 'Other';
    }
  } catch (error) {
    return 'Unknown';
  }
}

module.exports = {
  extractUrlFromText,
  getPlatformFromUrl
};