require('dotenv').config();
const { Telegraf } = require('telegraf');
const mongoose = require('mongoose');
const winston = require('winston');
const express = require('express');
const cron = require('node-cron');
const fs = require('fs-extra');
const path = require('path');

// Import custom modules
const config = require('./config');
const database = require('./database');
const logger = require('./utils/logger');
const commandHandler = require('./handlers/commandHandler');
const messageHandler = require('./handlers/messageHandler');
const callbackHandler = require('./handlers/callbackHandler');
const adminHandler = require('./handlers/adminHandler');
const cleanupService = require('./services/cleanupService');
const systemMonitor = require('./services/systemMonitor');

// Initialize bot
const bot = new Telegraf(config.BOT_TOKEN);

// Create downloads directory if it doesn't exist
fs.ensureDirSync(path.join(__dirname, 'downloads'));

// Express server for keeping the bot alive (optional for production)
const app = express();
const PORT = process.env.PORT || 3000;

app.get('/', (req, res) => {
  res.send('Bot is running!');
});

// Initialize database connection
(async () => {
  try {
    await database.connect();
    logger.info('Connected to MongoDB');
    
    // Register bot middleware
    bot.use(async (ctx, next) => {
      const start = Date.now();
      await next();
      const ms = Date.now() - start;
      logger.debug(`Response time: ${ms}ms`);
    });

    // Register command handlers
    commandHandler.register(bot);
    
    // Register message handlers
    messageHandler.register(bot);
    
    // Register callback query handlers
    callbackHandler.register(bot);
    
    // Register admin handlers
    adminHandler.register(bot);
    
    // Schedule cleanup task to run every hour
    cron.schedule('0 * * * *', () => {
      cleanupService.cleanupDownloads();
    });
    
    // Schedule system monitoring task
    cron.schedule('*/30 * * * *', () => {
      systemMonitor.checkSystemStatus(bot);
    });

    // Start bot
    await bot.launch();
    logger.info('Bot started successfully');
    
    // Start express server
    app.listen(PORT, () => {
      logger.info(`Express server running on port ${PORT}`);
    });
    
    // Enable graceful stop
    process.once('SIGINT', () => bot.stop('SIGINT'));
    process.once('SIGTERM', () => bot.stop('SIGTERM'));
    
  } catch (error) {
    logger.error('Failed to start the bot:', error);
    process.exit(1);
  }
})();