require('dotenv').config();

module.exports = {
  BOT_TOKEN: process.env.BOT_TOKEN || '8213201966:AAHbgF8WkOuM9MN0LzBm7qRVVI96ZfJ75vM',
  MONGODB_URI: process.env.MONGODB_URI || 'mongodb+srv://allmaster:allinoneseXASWA@221@clustervideo.lht9ruf.mongodb.net/?retryWrites=true&w=majority&appName=Clustervideo',
  VIDEO_API_URL: process.env.VIDEO_API_URL || 'https://ai.aioserver.news/ap/api/',
  VIDEO_API_KEY: process.env.VIDEO_API_KEY || '91f5fd40338ce7444e7870922617213952c89122980594fd28b19f80b2a6d9f8',
  ADMIN_IDS: (process.env.ADMIN_IDS || '5953036152,7759035155').split(',').map(id => id.trim()),
  MAX_FILE_SIZE: process.env.MAX_FILE_SIZE ? parseInt(process.env.MAX_FILE_SIZE) : 500 * 1024 * 1024, // 500MB default
  FREE_USER_DAILY_LIMIT: process.env.FREE_USER_DAILY_LIMIT ? parseInt(process.env.FREE_USER_DAILY_LIMIT) : 20,
  PREMIUM_USER_DAILY_LIMIT: process.env.PREMIUM_USER_DAILY_LIMIT ? parseInt(process.env.PREMIUM_USER_DAILY_LIMIT) : 500,
  DOWNLOAD_TIMEOUT: process.env.DOWNLOAD_TIMEOUT ? parseInt(process.env.DOWNLOAD_TIMEOUT) : 300000, // 5 minutes
  CLEANUP_INTERVAL: process.env.CLEANUP_INTERVAL ? parseInt(process.env.CLEANUP_INTERVAL) : 3600000, // 1 hour
};