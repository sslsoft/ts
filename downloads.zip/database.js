const mongoose = require('mongoose');
const config = require('./config');
const logger = require('./utils/logger');




// ✅ Direct MongoDB URI (password must be URL encoded)
const MONGODB_URI = 'mongodb+srv://allmaster:allinoneseXASWA%40221@clustervideo.lht9ruf.mongodb.net/?retryWrites=true&w=majority&appName=Clustervideo';

// ✅ For safe logging (hides password)
const sanitizedUri = MONGODB_URI.replace(
  /mongodb(\+srv)?:\/\/[^:]+:[^@]+@/,
  'mongodb$1://[username]:[password]@'
);

async function connect() {
  try {
    logger.info(`Connecting to MongoDB at: ${sanitizedUri}`);
    await mongoose.connect(MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    logger.info('✅ MongoDB connected successfully');
    return mongoose.connection;
  } catch (error) {
    logger.error('❌ MongoDB connection error:', error);
    throw error;
  }
}

module.exports = {
  connect,
  connection: mongoose.connection,
};
