const os = require('os');
const fs = require('fs-extra');
const mongoose = require('mongoose');
const axios = require('axios');
const Setting = require('../models/Setting');
const logger = require('../utils/logger');
const config = require('../config');

// Check system status
async function getSystemStats() {
  try {
    // Get bot uptime
    const uptime = formatUptime(process.uptime());
    
    // Get memory usage
    const memoryUsage = process.memoryUsage();
    const usedMemoryMB = Math.round(memoryUsage.rss / 1024 / 1024);
    const totalMemoryMB = Math.round(os.totalmem() / 1024 / 1024);
    const memoryUsageFormatted = `${usedMemoryMB}MB / ${totalMemoryMB}MB`;
    
    // Get CPU usage
    const cpuUsage = process.cpuUsage();
    const cpuUsagePercent = Math.round(
      (cpuUsage.user + cpuUsage.system) / 1000 / os.cpus().length / 10
    );
    const cpuUsageFormatted = `${cpuUsagePercent}%`;
    
    // Get disk space
    const { size, used } = await getDiskSpace();
    const diskSpaceFormatted = `${formatFileSize(used)} / ${formatFileSize(size)}`;
    
    // Check API status
    const apiStatus = await checkApiStatus();
    
    // Check database status
    const dbStatus = mongoose.connection.readyState === 1;
    
    // Get download function status
    const downloadEnabledSetting = await Setting.findOne({ key: 'downloadEnabled' });
    const downloadEnabled = downloadEnabledSetting ? downloadEnabledSetting.value : true;
    
    // Get maintenance mode status
    const maintenanceModeSetting = await Setting.findOne({ key: 'maintenanceMode' });
    const maintenanceMode = maintenanceModeSetting ? maintenanceModeSetting.value : false;
    
    // Return stats object
    return {
      uptime,
      memoryUsage: memoryUsageFormatted,
      cpuUsage: cpuUsageFormatted,
      diskSpace: diskSpaceFormatted,
      apiStatus,
      dbStatus,
      downloadEnabled,
      maintenanceMode,
      lastError: global.lastError || null,
      lastErrorTime: global.lastErrorTime || null
    };
    
  } catch (error) {
    logger.error('Error getting system stats:', error);
    
    // Return basic stats on error
    return {
      uptime: formatUptime(process.uptime()),
      memoryUsage: 'Error',
      cpuUsage: 'Error',
      diskSpace: 'Error',
      apiStatus: false,
      dbStatus: mongoose.connection.readyState === 1,
      downloadEnabled: true,
      maintenanceMode: false,
      lastError: error.message,
      lastErrorTime: new Date().toISOString()
    };
  }
}

// Check system status and notify admin if there's an issue
async function checkSystemStatus(bot) {
  try {
    const stats = await getSystemStats();
    
    // Define thresholds
    const memoryThreshold = 90; // 90% of total memory
    const diskSpaceThreshold = 90; // 90% of total disk space
    
    // Extract memory usage percentage
    const memoryUsed = parseInt(stats.memoryUsage.split('MB')[0]);
    const memoryTotal = parseInt(stats.memoryUsage.split('/')[1].trim().split('MB')[0]);
    const memoryPercentage = Math.round((memoryUsed / memoryTotal) * 100);
    
    // Extract disk space percentage
    const diskUsed = extractBytes(stats.diskSpace.split('/')[0]);
    const diskTotal = extractBytes(stats.diskSpace.split('/')[1]);
    const diskPercentage = Math.round((diskUsed / diskTotal) * 100);
    
    // Check for critical issues
    const criticalIssues = [];
    
    if (memoryPercentage > memoryThreshold) {
      criticalIssues.push(`⚠️ High memory usage: ${memoryPercentage}%`);
    }
    
    if (diskPercentage > diskSpaceThreshold) {
      criticalIssues.push(`⚠️ Low disk space: ${diskPercentage}% used`);
    }
    
    if (!stats.apiStatus) {
      criticalIssues.push('⚠️ API is unreachable');
    }
    
    if (!stats.dbStatus) {
      criticalIssues.push('⚠️ Database connection lost');
    }
    
    // If there are critical issues, notify admins
    if (criticalIssues.length > 0) {
      // Get all admins
      const User = require('../models/User');
      const admins = await User.find({ isAdmin: true });
      
      // Construct the alert message
      const alertMessage = `
*SYSTEM ALERT*

The following issues require attention:
${criticalIssues.join('\n')}

*System Stats:*
Memory: ${stats.memoryUsage} (${memoryPercentage}%)
Disk: ${stats.diskSpace} (${diskPercentage}%)
CPU: ${stats.cpuUsage}
API Status: ${stats.apiStatus ? '✅' : '❌'}
Database: ${stats.dbStatus ? '✅' : '❌'}

*Time:* ${new Date().toISOString()}
      `;
      
      // Notify each admin
      for (const admin of admins) {
        try {
          await bot.telegram.sendMessage(admin.userId, alertMessage, {
            parse_mode: 'Markdown'
          });
        } catch (notifyError) {
          logger.error(`Failed to notify admin ${admin.userId}:`, notifyError);
        }
      }
      
      logger.warn('System alert sent to admins:', criticalIssues);
    }
    
  } catch (error) {
    logger.error('Error checking system status:', error);
    
    // Store the last error globally
    global.lastError = error.message;
    global.lastErrorTime = new Date().toISOString();
  }
}

// Helper function to format uptime
function formatUptime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  const hours = Math.floor((seconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  
  let result = '';
  if (days > 0) result += `${days}d `;
  if (hours > 0 || days > 0) result += `${hours}h `;
  if (minutes > 0 || hours > 0 || days > 0) result += `${minutes}m `;
  result += `${secs}s`;
  
  return result;
}

// Helper function to get disk space
async function getDiskSpace() {
  // This is a simplified version and may not work in all environments
  // For production, consider using a package like 'diskusage'
  
  const downloadsDir = path.join(__dirname, '../downloads');
  
  // Ensure directory exists
  await fs.ensureDir(downloadsDir);
  
  // On non-Windows platforms, use df command
  if (os.platform() !== 'win32') {
    try {
      const { exec } = require('child_process');
      const util = require('util');
      const execAsync = util.promisify(exec);
      
      const { stdout } = await execAsync(`df -k "${downloadsDir}"`);
      const lines = stdout.trim().split('\n');
      const parts = lines[1].split(/\s+/);
      
      const size = parseInt(parts[1]) * 1024;
      const used = parseInt(parts[2]) * 1024;
      
      return { size, used };
    } catch (error) {
      logger.error('Error getting disk space:', error);
    }
  }
  
  // Fallback or for Windows
  return {
    size: os.totalmem(),
    used: os.totalmem() - os.freemem()
  };
}

// Helper function to check API status
async function checkApiStatus() {
  try {
    // Get API settings
    const apiKeySetting = await Setting.findOne({ key: 'apiKey' });
    const apiUrlSetting = await Setting.findOne({ key: 'apiUrl' });
    
    const apiKey = apiKeySetting ? apiKeySetting.value : config.VIDEO_API_KEY;
    const apiUrl = apiUrlSetting ? apiUrlSetting.value : config.VIDEO_API_URL;
    
    // Make a test request to the API
    const response = await axios({
      method: 'get',
      url: apiUrl,
      params: {
        url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', // Test URL
        api_key: apiKey
      },
      timeout: 5000 // 5 second timeout
    });
    
    return response.status === 200;
  } catch (error) {
    logger.error('API status check failed:', error);
    return false;
  }
}

// Helper function to format file size
function formatFileSize(bytes) {
  if (!bytes || isNaN(bytes)) return '0 B';
  
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  
  return `${(bytes / Math.pow(1024, i)).toFixed(2)} ${sizes[i]}`;
}

// Helper function to extract bytes from formatted string
function extractBytes(formattedSize) {
  const sizeStr = formattedSize.trim();
  const value = parseFloat(sizeStr);
  
  if (sizeStr.includes('KB')) {
    return value * 1024;
  } else if (sizeStr.includes('MB')) {
    return value * 1024 * 1024;
  } else if (sizeStr.includes('GB')) {
    return value * 1024 * 1024 * 1024;
  } else if (sizeStr.includes('TB')) {
    return value * 1024 * 1024 * 1024 * 1024;
  } else {
    return value;
  }
}

module.exports = {
  getSystemStats,
  checkSystemStatus
};