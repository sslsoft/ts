const fs = require('fs-extra');
const path = require('path');
const logger = require('../utils/logger');
const Download = require('../models/Download');

// Cleanup downloads directory
async function cleanupDownloads() {
  try {
    const downloadsDir = path.join(__dirname, '../downloads');
    
    // Ensure the directory exists
    await fs.ensureDir(downloadsDir);
    
    // Get all files in the directory
    const files = await fs.readdir(downloadsDir);
    
    // Get current time
    const now = Date.now();
    
    // Loop through each file
    for (const file of files) {
      try {
        const filePath = path.join(downloadsDir, file);
        
        // Get file stats
        const stats = await fs.stat(filePath);
        
        // Delete files older than 1 hour
        if (now - stats.mtimeMs > 3600000) {
          await fs.unlink(filePath);
          logger.debug(`Deleted old file: ${file}`);
        }
      } catch (fileError) {
        logger.error(`Error processing file ${file}:`, fileError);
      }
    }
    
    // Cleanup completed downloads older than 7 days
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    
    await Download.deleteMany({
      status: 'completed',
      createdAt: { $lt: sevenDaysAgo }
    });
    
    logger.info('Cleanup completed successfully');
    
  } catch (error) {
    logger.error('Error during cleanup:', error);
  }
}

module.exports = {
  cleanupDownloads
};