const axios = require('axios');
const fs = require('fs-extra');
const path = require('path');
const User = require('../models/User');
const Download = require('../models/Download');
const Setting = require('../models/Setting');
const logger = require('../utils/logger');
const config = require('../config');
const { getPlatformFromUrl } = require('../utils/urlUtils');

// Main download function
async function downloadVideo(bot, ctx, user, download, statusMessageId) {
  try {
    // Get API settings
    const apiKeySetting = await Setting.findOne({ key: 'apiKey' });
    const apiUrlSetting = await Setting.findOne({ key: 'apiUrl' });
    
    const apiKey = apiKeySetting ? apiKeySetting.value : config.VIDEO_API_KEY;
    const apiUrl = apiUrlSetting ? apiUrlSetting.value : config.VIDEO_API_URL;
    
    // Update download status
    download.status = 'downloading';
    await download.save();
    
    // Update status message
    await updateStatusMessage(bot, ctx.chat.id, statusMessageId, download);
    
    // Start timing the download
    const startTime = Date.now();
    
    // Make API request
    const response = await axios({
      method: 'get',
      url: apiUrl,
      params: {
        url: download.url,
        api_key: apiKey
      },
      responseType: 'json',
      timeout: config.DOWNLOAD_TIMEOUT
    });
    
    // Check if API response is valid
    if (!response.data || response.data.error) {
      throw new Error(response.data?.error || 'Invalid API response');
    }
    
    // Extract video information
    const videoInfo = response.data;
    
    // Update download with video info
    download.title = videoInfo.title || 'Untitled Video';
    download.thumbnail = videoInfo.thumbnail || null;
    download.duration = videoInfo.duration || 0;
    download.quality = videoInfo.quality || 'unknown';
    await download.save();
    
    // Update status message
    await updateStatusMessage(bot, ctx.chat.id, statusMessageId, download);
    
    // Create a unique filename
    const filename = `${Date.now()}_${user.userId}_${Math.floor(Math.random() * 10000)}.mp4`;
    const filepath = path.join(__dirname, '../downloads', filename);
    
    // Download the video file
    const videoUrl = videoInfo.url || videoInfo.download_url || videoInfo.stream_url;
    
    if (!videoUrl) {
      throw new Error('No video URL found in API response');
    }
    
    // Update download status
    download.status = 'downloading';
    await download.save();
    
    // Update status message
    await updateStatusMessage(bot, ctx.chat.id, statusMessageId, download);
    
    // Download the video file
    const writer = fs.createWriteStream(filepath);
    
    const videoResponse = await axios({
      method: 'get',
      url: videoUrl,
      responseType: 'stream',
      timeout: config.DOWNLOAD_TIMEOUT
    });
    
    videoResponse.data.pipe(writer);
    
    await new Promise((resolve, reject) => {
      writer.on('finish', resolve);
      writer.on('error', reject);
    });
    
    // Get file size
    const fileStats = await fs.stat(filepath);
    download.fileSize = fileStats.size;
    
    // Update download status
    download.status = 'uploading';
    await download.save();
    
    // Update status message
    await updateStatusMessage(bot, ctx.chat.id, statusMessageId, download);
    
    // Upload the video to Telegram
    await ctx.replyWithVideo(
      { source: filepath },
      {
        caption: `*${download.title}*\n\nPlatform: ${download.platform}\nQuality: ${download.quality}\nSize: ${formatFileSize(download.fileSize)}\nDownloaded by: @${ctx.from.username || ctx.from.first_name}`,
        parse_mode: 'Markdown'
      }
    );
    
    // Calculate download time
    const endTime = Date.now();
    download.downloadTime = endTime - startTime;
    
    // Update download status
    download.status = 'completed';
    await download.save();
    
    // Update status message with completion
    await bot.telegram.editMessageText(
      ctx.chat.id,
      statusMessageId,
      undefined,
      `✅ *Download Completed!*\n\nTitle: ${download.title}\nPlatform: ${download.platform}\nSize: ${formatFileSize(download.fileSize)}\nTime: ${Math.round(download.downloadTime / 1000)}s`,
      { parse_mode: 'Markdown' }
    );
    
    // Delete the file after sending
    try {
      await fs.unlink(filepath);
    } catch (error) {
      logger.error(`Failed to delete file ${filepath}:`, error);
    }
    
    // Update user statistics
    user.totalDownloads += 1;
    user.dailyDownloads += 1;
    user.lastDownloadDate = new Date();
    user.incrementPlatformCount(download.platform);
    await user.save();
    
  } catch (error) {
    logger.error(`Download failed for ${download.url}:`, error);
    
    // Update download status
    download.status = 'failed';
    download.error = error.message;
    await download.save();
    
    // Update status message with error
    try {
      await bot.telegram.editMessageText(
        ctx.chat.id,
        statusMessageId,
        undefined,
        `❌ *Download Failed!*\n\nURL: ${download.url}\nError: ${error.message}\n\nPlease try again or try another link.`,
        { parse_mode: 'Markdown' }
      );
    } catch (msgError) {
      logger.error('Failed to update status message with error:', msgError);
    }
  }
}

// Helper function to update the status message
async function updateStatusMessage(bot, chatId, messageId, download) {
  try {
    let statusText = '';
    
    switch (download.status) {
      case 'pending':
        statusText = `
*Processing your request*

URL: \`${download.url}\`
Platform: ${download.platform || 'Unknown'}
Status: Pending...

Please wait while I process your video...
        `;
        break;
        
      case 'downloading':
        statusText = `
*Downloading Video*

Title: ${download.title || 'Unknown'}
Platform: ${download.platform || 'Unknown'}
Status: Downloading... ⬇️

Please wait, this may take a few moments...
        `;
        break;
        
      case 'uploading':
        statusText = `
*Uploading Video*

Title: ${download.title || 'Unknown'}
Platform: ${download.platform || 'Unknown'}
Size: ${formatFileSize(download.fileSize)}
Status: Uploading to Telegram... ⬆️

Almost done...
        `;
        break;
        
      case 'completed':
        statusText = `
*Download Completed!* ✅

Title: ${download.title || 'Unknown'}
Platform: ${download.platform || 'Unknown'}
Size: ${formatFileSize(download.fileSize)}
Status: Completed

Your video has been sent!
        `;
        break;
        
      case 'failed':
        statusText = `
*Download Failed!* ❌

URL: \`${download.url}\`
Platform: ${download.platform || 'Unknown'}
Error: ${download.error || 'Unknown error'}

Please try again or try another link.
        `;
        break;
    }
    
    await bot.telegram.editMessageText(
      chatId,
      messageId,
      undefined,
      statusText,
      { parse_mode: 'Markdown' }
    );
    
  } catch (error) {
    logger.error('Failed to update status message:', error);
  }
}

// Helper function to format file size
function formatFileSize(bytes) {
  if (!bytes || isNaN(bytes)) return '0 B';
  
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  
  return `${(bytes / Math.pow(1024, i)).toFixed(2)} ${sizes[i]}`;
}

module.exports = {
  downloadVideo
};