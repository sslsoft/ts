const mongoose = require('mongoose');

const settingSchema = new mongoose.Schema({
  key: {
    type: String,
    required: true,
    unique: true
  },
  value: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  },
  description: String,
  updatedBy: Number,
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Default settings initialization
settingSchema.statics.initializeDefaults = async function() {
  const defaultSettings = [
    {
      key: 'downloadEnabled',
      value: true,
      description: 'Enable/disable download functionality'
    },
    {
      key: 'apiKey',
      value: require('../config').VIDEO_API_KEY,
      description: 'API key for video download service'
    },
    {
      key: 'apiUrl',
      value: require('../config').VIDEO_API_URL,
      description: 'API URL for video download service'
    },
    {
      key: 'freeUserDailyLimit',
      value: require('../config').FREE_USER_DAILY_LIMIT,
      description: 'Daily download limit for free users'
    },
    {
      key: 'premiumUserDailyLimit',
      value: require('../config').PREMIUM_USER_DAILY_LIMIT,
      description: 'Daily download limit for premium users'
    },
    {
      key: 'maintenanceMode',
      value: false,
      description: 'Bot maintenance mode'
    },
    {
      key: 'welcomeMessage',
      value: 'Welcome to the All-in-One Video Downloader Bot! Send me any video link to download it.',
      description: 'Welcome message for new users'
    }
  ];

  const operations = defaultSettings.map(setting => ({
    updateOne: {
      filter: { key: setting.key },
      update: { $setOnInsert: setting },
      upsert: true
    }
  }));

  if (operations.length > 0) {
    await this.bulkWrite(operations);
  }
};

module.exports = mongoose.model('Setting', settingSchema);