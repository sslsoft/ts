const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  userId: {
    type: Number,
    required: true,
    unique: true
  },
  username: {
    type: String,
    sparse: true
  },
  firstName: String,
  lastName: String,
  isPremium: {
    type: Boolean,
    default: false
  },
  isAdmin: {
    type: Boolean,
    default: false
  },
  isModerator: {
    type: Boolean,
    default: false
  },
  registeredAt: {
    type: Date,
    default: Date.now
  },
  lastActive: {
    type: Date,
    default: Date.now
  },
  totalDownloads: {
    type: Number,
    default: 0
  },
  dailyDownloads: {
    type: Number,
    default: 0
  },
  lastDownloadDate: {
    type: Date,
    default: null
  },
  platforms: {
    type: Map,
    of: Number,
    default: {}
  },
  language: {
    type: String,
    default: 'en'
  },
  banned: {
    type: Boolean,
    default: false
  },
  notificationEnabled: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

// Reset daily downloads at midnight
userSchema.methods.resetDailyDownloadsIfNeeded = function() {
  const today = new Date().toDateString();
  const lastDownloadDay = this.lastDownloadDate ? this.lastDownloadDate.toDateString() : null;
  
  if (lastDownloadDay !== today) {
    this.dailyDownloads = 0;
    return true;
  }
  return false;
};

// Increment download count for a specific platform
userSchema.methods.incrementPlatformCount = function(platform) {
  const currentCount = this.platforms.get(platform) || 0;
  this.platforms.set(platform, currentCount + 1);
};

// Check if user has reached daily limit
userSchema.methods.hasReachedDailyLimit = function() {
  const limit = this.isPremium ? 
    require('../config').PREMIUM_USER_DAILY_LIMIT : 
    require('../config').FREE_USER_DAILY_LIMIT;
  
  return this.dailyDownloads >= limit;
};

module.exports = mongoose.model('User', userSchema);