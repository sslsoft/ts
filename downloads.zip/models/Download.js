const mongoose = require('mongoose');

const downloadSchema = new mongoose.Schema({
  userId: {
    type: Number,
    required: true,
    index: true
  },
  platform: {
    type: String,
    required: true
  },
  url: {
    type: String,
    required: true
  },
  fileSize: {
    type: Number,
    default: 0
  },
  duration: {
    type: Number,
    default: 0
  },
  quality: String,
  title: String,
  thumbnail: String,
  status: {
    type: String,
    enum: ['pending', 'downloading', 'uploading', 'completed', 'failed'],
    default: 'pending'
  },
  error: String,
  downloadTime: {
    type: Number,
    default: 0
  },
  createdAt: {
    type: Date,
    default: Date.now,
    index: true
  }
});

module.exports = mongoose.model('Download', downloadSchema);