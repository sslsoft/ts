const User = require('../models/User');
const Download = require('../models/Download');
const Message = require('../models/Message');
const Setting = require('../models/Setting');
const logger = require('../utils/logger');
const config = require('../config');
const { extractUrlFromText, getPlatformFromUrl } = require('../utils/urlUtils');
const { downloadVideo } = require('../services/downloadService');
const { getKeyboard } = require('../utils/keyboard');

// Message handler registration
function register(bot) {
  // Handle text messages
  bot.on('text', async (ctx) => {
    try {
      const userId = ctx.from.id;
      const chatId = ctx.chat.id;
      const messageText = ctx.message.text;
      
      // Update user's last active timestamp
      await User.updateOne({ userId }, { $set: { lastActive: new Date() } });
      
      // Check if user is in a specific state (e.g., contacting admin)
      if (ctx.session && ctx.session.state === 'waiting_for_contact_message') {
        if (messageText.toLowerCase() === '/cancel') {
          delete ctx.session.state;
          return ctx.reply('Message to admin cancelled.');
        }
        
        // Create new message to admin
        const admins = await User.find({ isAdmin: true });
        if (admins.length === 0) {
          return ctx.reply('No admin is currently available. Please try again later.');
        }
        
        // Create a message to each admin
        for (const admin of admins) {
          const message = new Message({
            from: userId,
            to: admin.userId,
            text: messageText,
            createdAt: new Date()
          });
          
          await message.save();
        }
        
        delete ctx.session.state;
        return ctx.reply('Your message has been sent to the admin. You will receive a reply soon.');
      }
      
      // Check if admin is replying to a user
      if (ctx.session && ctx.session.state === 'admin_replying' && ctx.session.replyToUser) {
        if (messageText.toLowerCase() === '/cancel') {
          delete ctx.session.state;
          delete ctx.session.replyToUser;
          return ctx.reply('Reply cancelled.');
        }
        
        // Send the admin's reply to the user
        const message = new Message({
          from: userId,
          to: ctx.session.replyToUser,
          text: messageText,
          createdAt: new Date()
        });
        
        await message.save();
        
        // Try to forward the message to the user
        try {
          await bot.telegram.sendMessage(ctx.session.replyToUser, 
            `*Message from Admin:*\n\n${messageText}`,
            { parse_mode: 'Markdown' }
          );
          
          delete ctx.session.state;
          delete ctx.session.replyToUser;
          return ctx.reply('Your reply has been sent to the user.');
        } catch (error) {
          logger.error(`Failed to send admin reply to user ${ctx.session.replyToUser}:`, error);
          return ctx.reply('Failed to deliver your message to the user. They may have blocked the bot.');
        }
      }
      
      // Extract URL from message
      const url = extractUrlFromText(messageText);
      
      if (!url) {
        return ctx.reply('No valid URL found in your message. Please send a valid video URL.');
      }
      
      // Get user from database
      const user = await User.findOne({ userId });
      
      if (!user) {
        return ctx.reply('You are not registered. Please use /start to register first.');
      }
      
      // Check if download functionality is enabled
      const downloadEnabledSetting = await Setting.findOne({ key: 'downloadEnabled' });
      const downloadEnabled = downloadEnabledSetting ? downloadEnabledSetting.value : true;
      
      if (!downloadEnabled && !user.isAdmin) {
        return ctx.reply('Download functionality is currently disabled by the admin. Please try again later.');
      }
      
      // Check maintenance mode
      const maintenanceModeSetting = await Setting.findOne({ key: 'maintenanceMode' });
      const maintenanceMode = maintenanceModeSetting ? maintenanceModeSetting.value : false;
      
      if (maintenanceMode && !user.isAdmin) {
        return ctx.reply('The bot is currently under maintenance. Please try again later.');
      }
      
      // Reset daily downloads if it's a new day
      if (user.resetDailyDownloadsIfNeeded()) {
        user.lastDownloadDate = new Date();
        await user.save();
      }
      
      // Check if user has reached daily limit
      if (user.hasReachedDailyLimit() && !user.isAdmin) {
        const limit = user.isPremium ? config.PREMIUM_USER_DAILY_LIMIT : config.FREE_USER_DAILY_LIMIT;
        
        return ctx.reply(`
You have reached your daily download limit of ${limit} videos.
${user.isPremium ? '' : 'Consider upgrading to Premium for higher limits by using /premium command.'}
Your limit will reset at midnight UTC.
        `);
      }
      
      // Extract platform
      const platform = getPlatformFromUrl(url);
      
      // Create download record
      const download = new Download({
        userId,
        platform,
        url,
        status: 'pending',
        createdAt: new Date()
      });
      
      await download.save();
      
      // Send initial message
      const statusMessage = await ctx.reply(`
*Processing your request*

URL: \`${url}\`
Platform: ${platform || 'Unknown'}
Status: Downloading...

Please wait while I process your video...
      `, {
        parse_mode: 'Markdown'
      });
      
      // Process the download
      await downloadVideo(bot, ctx, user, download, statusMessage.message_id);
      
    } catch (error) {
      logger.error('Error handling text message:', error);
      await ctx.reply('An error occurred while processing your request. Please try again later.');
    }
  });
  
  // Handle private admin message replies (when admin replies to a forwarded message)
  bot.on('message', async (ctx, next) => {
    // Only process if it's a reply and from an admin
    if (ctx.message.reply_to_message && ctx.message.reply_to_message.forward_from) {
      try {
        const adminId = ctx.from.id;
        const admin = await User.findOne({ userId: adminId, isAdmin: true });
        
        // If sender is not admin, proceed to next middleware
        if (!admin) {
          return next();
        }
        
        const replyToUserId = ctx.message.reply_to_message.forward_from.id;
        const replyText = ctx.message.text || 'Admin sent a response (non-text message)';
        
        // Create and save the reply message
        const message = new Message({
          from: adminId,
          to: replyToUserId,
          text: replyText,
          createdAt: new Date()
        });
        
        await message.save();
        
        // Send the reply to the user
        try {
          await bot.telegram.sendMessage(replyToUserId, 
            `*Message from Admin:*\n\n${replyText}`,
            { parse_mode: 'Markdown' }
          );
          
          await ctx.reply(`Your reply has been sent to the user (ID: ${replyToUserId}).`);
        } catch (error) {
          logger.error(`Failed to send admin reply to user ${replyToUserId}:`, error);
          await ctx.reply('Failed to deliver your message to the user. They may have blocked the bot.');
        }
      } catch (error) {
        logger.error('Error handling admin reply:', error);
        await ctx.reply('An error occurred while sending your reply.');
      }
    } else {
      return next();
    }
  });
}

module.exports = {
  register
};