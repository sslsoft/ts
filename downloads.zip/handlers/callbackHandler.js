    const User = require('../models/User');
const Download = require('../models/Download');
const Setting = require('../models/Setting');
const Message = require('../models/Message');
const logger = require('../utils/logger');
const config = require('../config');
const { getSystemStats } = require('../services/systemMonitor');

// Callback query handler registration
function register(bot) {
  bot.on('callback_query', async (ctx) => {
    try {
      const callbackData = ctx.callbackQuery.data;
      const userId = ctx.from.id;
      
      // Get user from database
      const user = await User.findOne({ userId });
      
      if (!user) {
        return ctx.answerCallbackQuery('User not found. Please use /start to register.');
      }
      
      // Update user's last active timestamp
      user.lastActive = new Date();
      await user.save();
      
      // Handle different callback queries based on the data
      if (callbackData === 'toggle_notifications') {
        await handleToggleNotifications(ctx, user);
      } else if (callbackData === 'change_language') {
        await handleChangeLanguage(ctx, user);
      } else if (callbackData === 'settings_done') {
        await ctx.deleteMessage();
        await ctx.answerCallbackQuery('Settings saved!');
      } else if (callbackData.startsWith('admin_')) {
        // Check if user is admin or moderator
        if (!user.isAdmin && !user.isModerator) {
          return ctx.answerCallbackQuery('You do not have permission to access admin functions.');
        }
        
        // Handle admin-specific callbacks
        if (callbackData === 'admin_stats') {
          await handleAdminStats(ctx, user);
        } else if (callbackData === 'admin_users') {
          await handleAdminUsers(ctx, user);
        } else if (callbackData === 'admin_system') {
          await handleAdminSystem(ctx, user);
        } else if (callbackData === 'admin_settings') {
          await handleAdminSettings(ctx, user);
        } else if (callbackData === 'admin_broadcast') {
          await handleAdminBroadcast(ctx, user);
        } else if (callbackData === 'admin_messages') {
          await handleAdminMessages(ctx, user);
        } else if (callbackData.startsWith('admin_toggle_download_')) {
          await handleToggleDownloadFunction(ctx, user);
        } else if (callbackData.startsWith('admin_toggle_maintenance_')) {
          await handleToggleMaintenanceMode(ctx, user);
        } else if (callbackData.startsWith('admin_user_action_')) {
          await handleUserAction(ctx, user, callbackData);
        } else if (callbackData.startsWith('admin_update_limit_')) {
          await handleUpdateLimit(ctx, user, callbackData);
        } else if (callbackData.startsWith('admin_update_api_')) {
          await handleUpdateApi(ctx, user, callbackData);
        } else if (callbackData.startsWith('admin_update_welcome_')) {
          await handleUpdateWelcomeMessage(ctx, user);
        } else if (callbackData.startsWith('admin_msg_')) {
          await handleMessageAction(ctx, user, callbackData);
        }
      } else if (callbackData.startsWith('lang_')) {
        // Handle language selection
        const language = callbackData.replace('lang_', '');
        user.language = language;
        await user.save();
        
        await ctx.answerCallbackQuery(`Language changed to ${language}!`);
        await ctx.editMessageText('Your language preference has been updated.');
      }
      
    } catch (error) {
      logger.error('Error handling callback query:', error);
      await ctx.answerCallbackQuery('An error occurred. Please try again.');
    }
  });
}

// Toggle user notifications
async function handleToggleNotifications(ctx, user) {
  user.notificationEnabled = !user.notificationEnabled;
  await user.save();
  
  await ctx.answerCallbackQuery(`Notifications ${user.notificationEnabled ? 'enabled' : 'disabled'}`);
  
  // Update the settings keyboard
  const settingsKeyboard = {
    inline_keyboard: [
      [
        { 
          text: `Notifications: ${user.notificationEnabled ? '✅ ON' : '❌ OFF'}`, 
          callback_data: 'toggle_notifications' 
        }
      ],
      [
        { 
          text: 'Change Language', 
          callback_data: 'change_language' 
        }
      ],
      [
        {
          text: 'Done',
          callback_data: 'settings_done'
        }
      ]
    ]
  };
  
  await ctx.editMessageReplyMarkup(settingsKeyboard);
}

// Handle language change
async function handleChangeLanguage(ctx, user) {
  const languageKeyboard = {
    inline_keyboard: [
      [
        { text: 'English 🇬🇧', callback_data: 'lang_en' },
        { text: 'Spanish 🇪🇸', callback_data: 'lang_es' }
      ],
      [
        { text: 'French 🇫🇷', callback_data: 'lang_fr' },
        { text: 'German 🇩🇪', callback_data: 'lang_de' }
      ],
      [
        { text: 'Russian 🇷🇺', callback_data: 'lang_ru' },
        { text: 'Arabic 🇸🇦', callback_data: 'lang_ar' }
      ],
      [
        { text: 'Cancel', callback_data: 'settings_done' }
      ]
    ]
  };
  
  await ctx.editMessageText('Select your preferred language:', {
    reply_markup: languageKeyboard
  });
}

// Admin stats handler
async function handleAdminStats(ctx, user) {
  try {
    // Get total users count
    const totalUsers = await User.countDocuments();
    const premiumUsers = await User.countDocuments({ isPremium: true });
    const activeToday = await User.countDocuments({ lastActive: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } });
    
    // Get download stats
    const totalDownloads = await Download.countDocuments();
    const completedDownloads = await Download.countDocuments({ status: 'completed' });
    const failedDownloads = await Download.countDocuments({ status: 'failed' });
    
    // Get downloads by platform
    const platforms = await Download.aggregate([
      { $group: { _id: '$platform', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 5 }
    ]);
    
    // Get downloads in the last 7 days
    const last7Days = await Download.aggregate([
      { 
        $match: { 
          createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } 
        } 
      },
      { 
        $group: { 
          _id: { 
            $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } 
          }, 
          count: { $sum: 1 } 
        } 
      },
      { $sort: { _id: 1 } }
    ]);
    
    // Format platform stats
    let platformsText = platforms.map(p => `${p._id || 'Unknown'}: ${p.count}`).join('\n');
    if (!platformsText) platformsText = 'No data available';
    
    // Format daily stats
    let dailyText = last7Days.map(d => `${d._id}: ${d.count}`).join('\n');
    if (!dailyText) dailyText = 'No data available';
    
    const statsMessage = `
*Bot Statistics*

*Users:*
Total Users: ${totalUsers}
Premium Users: ${premiumUsers}
Active Today: ${activeToday}

*Downloads:*
Total Downloads: ${totalDownloads}
Completed: ${completedDownloads}
Failed: ${failedDownloads}
Success Rate: ${totalDownloads > 0 ? Math.round((completedDownloads / totalDownloads) * 100) : 0}%

*Top Platforms:*
${platformsText}

*Last 7 Days:*
${dailyText}
`;

    await ctx.editMessageText(statsMessage, {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '⬅️ Back to Admin Panel', callback_data: 'admin_back' }
          ]
        ]
      }
    });
    
  } catch (error) {
    logger.error('Error handling admin stats:', error);
    await ctx.answerCallbackQuery('Failed to load statistics');
  }
}

// Admin users handler
async function handleAdminUsers(ctx, user) {
  try {
    // Get recent users
    const recentUsers = await User.find()
      .sort({ lastActive: -1 })
      .limit(10);
    
    let usersMessage = '*User Management*\n\nRecent active users:\n\n';
    
    recentUsers.forEach((u, index) => {
      usersMessage += `*${index + 1}.* ${u.firstName} ${u.lastName}`;
      usersMessage += u.username ? ` (@${u.username})` : '';
      usersMessage += `\nID: ${u.userId}`;
      usersMessage += `\nType: ${u.isPremium ? '⭐ Premium' : '🔹 Free'}`;
      usersMessage += `\nRole: ${u.isAdmin ? '👑 Admin' : u.isModerator ? '🛡️ Moderator' : '👤 User'}`;
      usersMessage += `\nDownloads: ${u.totalDownloads}`;
      usersMessage += `\nLast active: ${u.lastActive.toISOString().split('T')[0]}\n\n`;
    });
    
    // Add user management options
    const userKeyboard = {
      inline_keyboard: [
        [
          { text: '🔍 Find User', callback_data: 'admin_find_user' },
          { text: '⭐ Manage Premium', callback_data: 'admin_manage_premium' }
        ],
        [
          { text: '🚫 Ban User', callback_data: 'admin_ban_user' },
          { text: '✉️ Message User', callback_data: 'admin_message_user' }
        ],
        [
          { text: '⬅️ Back to Admin Panel', callback_data: 'admin_back' }
        ]
      ]
    };
    
    await ctx.editMessageText(usersMessage, {
      parse_mode: 'Markdown',
      reply_markup: userKeyboard
    });
    
  } catch (error) {
    logger.error('Error handling admin users:', error);
    await ctx.answerCallbackQuery('Failed to load user management');
  }
}

// Admin system handler
async function handleAdminSystem(ctx, user) {
  try {
    const stats = await getSystemStats();
    
    const systemMessage = `
*System Status*

*Bot Uptime:* ${stats.uptime}
*Memory Usage:* ${stats.memoryUsage}
*CPU Usage:* ${stats.cpuUsage}
*Disk Space:* ${stats.diskSpace}

*API Status:* ${stats.apiStatus ? '✅ Online' : '❌ Offline'}
*Database Status:* ${stats.dbStatus ? '✅ Connected' : '❌ Disconnected'}

*Download Function:* ${stats.downloadEnabled ? '✅ Enabled' : '❌ Disabled'}
*Maintenance Mode:* ${stats.maintenanceMode ? '⚠️ Enabled' : '✅ Disabled'}

*Last Error:* ${stats.lastError || 'None'}
*Last Error Time:* ${stats.lastErrorTime || 'N/A'}
`;

    // System management options
    const systemKeyboard = {
      inline_keyboard: [
        [
          { 
            text: `Download Function: ${stats.downloadEnabled ? '✅ ON' : '❌ OFF'}`, 
            callback_data: `admin_toggle_download_${stats.downloadEnabled ? 'off' : 'on'}` 
          }
        ],
        [
          { 
            text: `Maintenance Mode: ${stats.maintenanceMode ? '⚠️ ON' : '✅ OFF'}`, 
            callback_data: `admin_toggle_maintenance_${stats.maintenanceMode ? 'off' : 'on'}` 
          }
        ],
        [
          { text: '🔄 Update API Key', callback_data: 'admin_update_api_key' },
          { text: '🔗 Update API URL', callback_data: 'admin_update_api_url' }
        ],
        [
          { text: '⬅️ Back to Admin Panel', callback_data: 'admin_back' }
        ]
      ]
    };
    
    await ctx.editMessageText(systemMessage, {
      parse_mode: 'Markdown',
      reply_markup: systemKeyboard
    });
    
  } catch (error) {
    logger.error('Error handling admin system:', error);
    await ctx.answerCallbackQuery('Failed to load system status');
  }
}

// Admin settings handler
async function handleAdminSettings(ctx, user) {
  try {
    // Get current settings
    const settings = await Setting.find();
    
    // Format settings into a readable message
    let settingsMessage = '*Bot Settings*\n\n';
    
    // Organize settings by category
    const generalSettings = settings.filter(s => 
      ['downloadEnabled', 'maintenanceMode', 'welcomeMessage'].includes(s.key));
    
    const limitSettings = settings.filter(s => 
      ['freeUserDailyLimit', 'premiumUserDailyLimit'].includes(s.key));
    
    const apiSettings = settings.filter(s => 
      ['apiKey', 'apiUrl'].includes(s.key));
    
    // Add general settings
    settingsMessage += '*General Settings:*\n';
    generalSettings.forEach(s => {
      if (s.key === 'apiKey') {
        // Mask API key for security
        const maskedValue = s.value.substring(0, 4) + '...' + s.value.substring(s.value.length - 4);
        settingsMessage += `${s.description}: \`${maskedValue}\`\n`;
      } else if (typeof s.value === 'boolean') {
        settingsMessage += `${s.description}: ${s.value ? '✅ Enabled' : '❌ Disabled'}\n`;
      } else {
        settingsMessage += `${s.description}: ${s.value}\n`;
      }
    });
    
    // Add limit settings
    settingsMessage += '\n*Limit Settings:*\n';
    limitSettings.forEach(s => {
      settingsMessage += `${s.description}: ${s.value}\n`;
    });
    
    // Add API settings
    settingsMessage += '\n*API Settings:*\n';
    apiSettings.forEach(s => {
      if (s.key === 'apiKey') {
        // Mask API key for security
        const maskedValue = s.value.substring(0, 4) + '...' + s.value.substring(s.value.length - 4);
        settingsMessage += `${s.description}: \`${maskedValue}\`\n`;
      } else {
        settingsMessage += `${s.description}: ${s.value}\n`;
      }
    });
    
    // Settings management options
    const settingsKeyboard = {
      inline_keyboard: [
        [
          { text: 'Update Free User Limit', callback_data: 'admin_update_limit_free' },
          { text: 'Update Premium User Limit', callback_data: 'admin_update_limit_premium' }
        ],
        [
          { text: 'Update API Key', callback_data: 'admin_update_api_key' },
          { text: 'Update API URL', callback_data: 'admin_update_api_url' }
        ],
        [
          { text: 'Update Welcome Message', callback_data: 'admin_update_welcome_message' }
        ],
        [
          { text: '⬅️ Back to Admin Panel', callback_data: 'admin_back' }
        ]
      ]
    };
    
    await ctx.editMessageText(settingsMessage, {
      parse_mode: 'Markdown',
      reply_markup: settingsKeyboard
    });
    
  } catch (error) {
    logger.error('Error handling admin settings:', error);
    await ctx.answerCallbackQuery('Failed to load settings');
  }
}

// Admin broadcast handler
async function handleAdminBroadcast(ctx, user) {
  try {
    // Set the session state for handling the broadcast message
    ctx.session = ctx.session || {};
    ctx.session.state = 'admin_broadcast';
    
    const broadcastMessage = `
*Broadcast Message*

You can send a message to all users of the bot.
To create a broadcast:

1. Reply to this message with your announcement
2. The message will be sent to all users
3. You'll receive a report after completion

*Options:*
- Send to all users
- Send to premium users only
- Send to free users only

*Format:*
You can use Markdown formatting in your message.
`;

    const broadcastKeyboard = {
      inline_keyboard: [
        [
          { text: 'All Users', callback_data: 'admin_broadcast_all' },
          { text: 'Premium Users', callback_data: 'admin_broadcast_premium' }
        ],
        [
          { text: 'Free Users', callback_data: 'admin_broadcast_free' },
          { text: 'Active Users (24h)', callback_data: 'admin_broadcast_active' }
        ],
        [
          { text: 'Cancel', callback_data: 'admin_back' }
        ]
      ]
    };
    
    await ctx.editMessageText(broadcastMessage, {
      parse_mode: 'Markdown',
      reply_markup: broadcastKeyboard
    });
    
  } catch (error) {
    logger.error('Error handling admin broadcast:', error);
    await ctx.answerCallbackQuery('Failed to load broadcast options');
  }
}

// Admin messages handler
async function handleAdminMessages(ctx, user) {
  try {
    // Get recent unread messages
    const unreadMessages = await Message.find({ 
      to: user.userId,
      read: false
    })
    .sort({ createdAt: -1 })
    .limit(10);
    
    let messageCount = await Message.countDocuments({ 
      to: user.userId,
      read: false
    });
    
    let messagesText = `*Admin Messages*\n\nYou have ${messageCount} unread message${messageCount !== 1 ? 's' : ''}.\n\n`;
    
    if (unreadMessages.length === 0) {
      messagesText += 'No unread messages.';
    } else {
      // Group messages by sender
      const messagesBySender = {};
      
      for (const msg of unreadMessages) {
        if (!messagesBySender[msg.from]) {
          messagesBySender[msg.from] = [];
        }
        messagesBySender[msg.from].push(msg);
      }
      
      // Display messages grouped by sender
      for (const [senderId, messages] of Object.entries(messagesBySender)) {
        const sender = await User.findOne({ userId: parseInt(senderId) });
        const senderName = sender ? 
          `${sender.firstName} ${sender.lastName}${sender.username ? ` (@${sender.username})` : ''}` : 
          `User ID: ${senderId}`;
        
        messagesText += `*From: ${senderName}*\n`;
        messagesText += `Messages: ${messages.length}\n`;
        messagesText += `Latest: ${messages[0].text.substring(0, 50)}${messages[0].text.length > 50 ? '...' : ''}\n`;
        messagesText += `Time: ${messages[0].createdAt.toISOString().split('T')[0]} ${messages[0].createdAt.toISOString().split('T')[1].substring(0, 5)}\n\n`;
      }
    }
    
    const messagesKeyboard = {
      inline_keyboard: [
        [
          { text: 'View All Messages', callback_data: 'admin_msg_view_all' },
          { text: 'Mark All Read', callback_data: 'admin_msg_mark_all_read' }
        ],
        [
          { text: 'Reply to User', callback_data: 'admin_msg_reply' }
        ],
        [
          { text: '⬅️ Back to Admin Panel', callback_data: 'admin_back' }
        ]
      ]
    };
    
    await ctx.editMessageText(messagesText, {
      parse_mode: 'Markdown',
      reply_markup: messagesKeyboard
    });
    
  } catch (error) {
    logger.error('Error handling admin messages:', error);
    await ctx.answerCallbackQuery('Failed to load messages');
  }
}

// Toggle download function
async function handleToggleDownloadFunction(ctx, user) {
  try {
    const newState = ctx.callbackQuery.data.endsWith('on');
    
    // Update the setting
    await Setting.updateOne(
      { key: 'downloadEnabled' },
      { $set: { value: newState, updatedBy: user.userId, updatedAt: new Date() } },
      { upsert: true }
    );
    
    await ctx.answerCallbackQuery(`Download function ${newState ? 'enabled' : 'disabled'}`);
    
    // Refresh the system status view
    await handleAdminSystem(ctx, user);
    
  } catch (error) {
    logger.error('Error toggling download function:', error);
    await ctx.answerCallbackQuery('Failed to update setting');
  }
}

// Toggle maintenance mode
async function handleToggleMaintenanceMode(ctx, user) {
  try {
    const newState = ctx.callbackQuery.data.endsWith('on');
    
    // Update the setting
    await Setting.updateOne(
      { key: 'maintenanceMode' },
      { $set: { value: newState, updatedBy: user.userId, updatedAt: new Date() } },
      { upsert: true }
    );
    
    await ctx.answerCallbackQuery(`Maintenance mode ${newState ? 'enabled' : 'disabled'}`);
    
    // Refresh the system status view
    await handleAdminSystem(ctx, user);
    
  } catch (error) {
    logger.error('Error toggling maintenance mode:', error);
    await ctx.answerCallbackQuery('Failed to update setting');
  }
}

// Handle user actions (e.g., promote, demote, ban)
async function handleUserAction(ctx, user, callbackData) {
  try {
    // Extract action and target user ID
    const parts = callbackData.split('_');
    const action = parts[3]; // e.g., promote, demote, ban
    const targetUserId = parseInt(parts[4]);
    
    // Get target user
    const targetUser = await User.findOne({ userId: targetUserId });
    
    if (!targetUser) {
      return ctx.answerCallbackQuery('User not found');
    }
    
    // Execute the action
    switch (action) {
      case 'promote':
        if (targetUser.isAdmin) {
          return ctx.answerCallbackQuery('User is already an admin');
        }
        
        targetUser.isAdmin = true;
        await targetUser.save();
        await ctx.answerCallbackQuery('User promoted to admin');
        break;
        
      case 'mod':
        if (targetUser.isModerator) {
          return ctx.answerCallbackQuery('User is already a moderator');
        }
        
        targetUser.isModerator = true;
        await targetUser.save();
        await ctx.answerCallbackQuery('User promoted to moderator');
        break;
        
      case 'demote':
        if (!targetUser.isAdmin && !targetUser.isModerator) {
          return ctx.answerCallbackQuery('User is already a regular user');
        }
        
        targetUser.isAdmin = false;
        targetUser.isModerator = false;
        await targetUser.save();
        await ctx.answerCallbackQuery('User demoted to regular user');
        break;
        
      case 'premium':
        if (targetUser.isPremium) {
          return ctx.answerCallbackQuery('User is already premium');
        }
        
        targetUser.isPremium = true;
        await targetUser.save();
        
        // Notify the user
        try {
          await ctx.telegram.sendMessage(targetUser.userId, 
            '*Congratulations!* 🎉\n\nYour account has been upgraded to Premium status! You now have access to all premium features, including higher download limits and priority processing.',
            { parse_mode: 'Markdown' }
          );
        } catch (error) {
          logger.error(`Failed to notify user ${targetUser.userId} about premium upgrade:`, error);
        }
        
        await ctx.answerCallbackQuery('User upgraded to premium');
        break;
        
      case 'unpremium':
        if (!targetUser.isPremium) {
          return ctx.answerCallbackQuery('User is already non-premium');
        }
        
        targetUser.isPremium = false;
        await targetUser.save();
        await ctx.answerCallbackQuery('User downgraded from premium');
        break;
        
      case 'ban':
        if (targetUser.banned) {
          return ctx.answerCallbackQuery('User is already banned');
        }
        
        targetUser.banned = true;
        await targetUser.save();
        await ctx.answerCallbackQuery('User banned');
        break;
        
      case 'unban':
        if (!targetUser.banned) {
          return ctx.answerCallbackQuery('User is not banned');
        }
        
        targetUser.banned = false;
        await targetUser.save();
        await ctx.answerCallbackQuery('User unbanned');
        break;
        
      default:
        await ctx.answerCallbackQuery('Unknown action');
    }
    
    // Refresh the user management view
    await handleAdminUsers(ctx, user);
    
  } catch (error) {
    logger.error('Error handling user action:', error);
    await ctx.answerCallbackQuery('Failed to perform action');
  }
}

// Handle updating limits
async function handleUpdateLimit(ctx, user, callbackData) {
  try {
    const limitType = callbackData.split('_')[3]; // free or premium
    
    // Set the session state for handling the limit update
    ctx.session = ctx.session || {};
    ctx.session.state = `admin_updating_limit_${limitType}`;
    
    const settingKey = limitType === 'free' ? 'freeUserDailyLimit' : 'premiumUserDailyLimit';
    const currentSetting = await Setting.findOne({ key: settingKey });
    const currentValue = currentSetting ? currentSetting.value : (limitType === 'free' ? 5 : 50);
    
    await ctx.editMessageText(`
*Update ${limitType === 'free' ? 'Free' : 'Premium'} User Daily Limit*

Current limit: ${currentValue}

Please reply to this message with the new limit value (must be a number).
    `, {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Cancel', callback_data: 'admin_settings' }
          ]
        ]
      }
    });
    
  } catch (error) {
    logger.error('Error handling update limit:', error);
    await ctx.answerCallbackQuery('Failed to load limit settings');
  }
}

// Handle updating API settings
async function handleUpdateApi(ctx, user, callbackData) {
  try {
    const apiPart = callbackData.split('_')[3]; // key or url
    
    // Set the session state for handling the API update
    ctx.session = ctx.session || {};
    ctx.session.state = `admin_updating_api_${apiPart}`;
    
    
    
    const settingKey = apiPart === 'key' ? 'apiKey' : 'apiUrl';
    const currentSetting = await Setting.findOne({ key: settingKey });
    let currentValue = currentSetting ? currentSetting.value : '';
    
    // Mask API key for security if showing the key
    if (apiPart === 'key' && currentValue) {
      currentValue = currentValue.substring(0, 4) + '...' + currentValue.substring(currentValue.length - 4);
    }
    
    await ctx.editMessageText(`
*Update API ${apiPart === 'key' ? 'Key' : 'URL'}*

Current value: \`${currentValue}\`

Please reply to this message with the new ${apiPart === 'key' ? 'API key' : 'API URL'}.
    `, {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Cancel', callback_data: 'admin_settings' }
          ]
        ]
      }
    });
    
  } catch (error) {
    logger.error('Error handling update API:', error);
    await ctx.answerCallbackQuery('Failed to load API settings');
  }
}

// Handle updating welcome message
async function handleUpdateWelcomeMessage(ctx, user) {
  try {
    // Set the session state for handling the welcome message update
    ctx.session = ctx.session || {};
    ctx.session.state = 'admin_updating_welcome';
    
    const currentSetting = await Setting.findOne({ key: 'welcomeMessage' });
    const currentValue = currentSetting ? currentSetting.value : 
      'Welcome to the All-in-One Video Downloader Bot! Send me any video link to download it.';
    
    await ctx.editMessageText(`
*Update Welcome Message*

Current message:
\`\`\`
${currentValue}
\`\`\`

Please reply to this message with the new welcome message.
You can use Markdown formatting.
    `, {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Cancel', callback_data: 'admin_settings' }
          ]
        ]
      }
    });
    
  } catch (error) {
    logger.error('Error handling update welcome message:', error);
    await ctx.answerCallbackQuery('Failed to load welcome message settings');
  }
}

// Handle message actions
async function handleMessageAction(ctx, user, callbackData) {
  try {
    const action = callbackData.split('_')[2]; // view_all, mark_all_read, reply
    
    if (action === 'view_all') {
      // Show all messages, paginated
      const messages = await Message.find({ to: user.userId })
        .sort({ createdAt: -1 })
        .limit(20);
      
      if (messages.length === 0) {
        return ctx.answerCallbackQuery('No messages found');
      }
      
      let messagesText = '*All Messages*\n\n';
      
      // Group messages by sender
      const messagesBySender = {};
      
      for (const msg of messages) {
        if (!messagesBySender[msg.from]) {
          messagesBySender[msg.from] = [];
        }
        messagesBySender[msg.from].push(msg);
      }
      
      // Display messages grouped by sender
      for (const [senderId, senderMessages] of Object.entries(messagesBySender)) {
        const sender = await User.findOne({ userId: parseInt(senderId) });
        const senderName = sender ? 
          `${sender.firstName} ${sender.lastName}${sender.username ? ` (@${sender.username})` : ''}` : 
          `User ID: ${senderId}`;
        
        messagesText += `*From: ${senderName}*\n`;
        
        // Show the latest 3 messages from this sender
        for (let i = 0; i < Math.min(3, senderMessages.length); i++) {
          const msg = senderMessages[i];
          messagesText += `- ${msg.text.substring(0, 100)}${msg.text.length > 100 ? '...' : ''}\n`;
          messagesText += `  ${msg.createdAt.toISOString().split('T')[0]} ${msg.createdAt.toISOString().split('T')[1].substring(0, 5)}\n`;
        }
        
        if (senderMessages.length > 3) {
          messagesText += `_(${senderMessages.length - 3} more messages)_\n`;
        }
        
        messagesText += '\n';
      }
      
      await ctx.editMessageText(messagesText, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [
              { text: 'Mark All Read', callback_data: 'admin_msg_mark_all_read' },
              { text: 'Reply to User', callback_data: 'admin_msg_reply' }
            ],
            [
              { text: '⬅️ Back', callback_data: 'admin_messages' }
            ]
          ]
        }
      });
      
    } else if (action === 'mark_all_read') {
      // Mark all messages as read
      await Message.updateMany(
        { to: user.userId, read: false },
        { $set: { read: true } }
      );
      
      await ctx.answerCallbackQuery('All messages marked as read');
      
      // Refresh messages view
      await handleAdminMessages(ctx, user);
      
    } else if (action === 'reply') {
      // Show list of users to reply to
      const recentSenders = await Message.aggregate([
        { $match: { to: user.userId } },
        { $group: { _id: '$from', lastMessage: { $max: '$createdAt' } } },
        { $sort: { lastMessage: -1 } },
        { $limit: 10 }
      ]);
      
      if (recentSenders.length === 0) {
        return ctx.answerCallbackQuery('No users to reply to');
      }
      
      let selectUserText = '*Select User to Reply To:*\n\n';
      const inlineKeyboard = [];
      
      for (const sender of recentSenders) {
        const senderUser = await User.findOne({ userId: sender._id });
        const senderName = senderUser ? 
          `${senderUser.firstName} ${senderUser.lastName}${senderUser.username ? ` (@${senderUser.username})` : ''}` : 
          `User ID: ${sender._id}`;
        
        selectUserText += `- ${senderName}\n`;
        
        inlineKeyboard.push([
          { text: senderName, callback_data: `admin_msg_reply_to_${sender._id}` }
        ]);
      }
      
      inlineKeyboard.push([
        { text: '⬅️ Back', callback_data: 'admin_messages' }
      ]);
      
      await ctx.editMessageText(selectUserText, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: inlineKeyboard
        }
      });
      
    } else if (action.startsWith('reply_to_')) {
      // Set up reply to specific user
      const targetUserId = parseInt(action.replace('reply_to_', ''));
      
      // Set session for replying
      ctx.session = ctx.session || {};
      ctx.session.state = 'admin_replying';
      ctx.session.replyToUser = targetUserId;
      
      // Get target user info
      const targetUser = await User.findOne({ userId: targetUserId });
      const targetName = targetUser ? 
        `${targetUser.firstName} ${targetUser.lastName}${targetUser.username ? ` (@${targetUser.username})` : ''}` : 
        `User ID: ${targetUserId}`;
      
      // Get recent messages from this user
      const recentMessages = await Message.find({ 
        from: targetUserId, 
        to: user.userId 
      })
      .sort({ createdAt: -1 })
      .limit(5);
      
      let replyText = `*Replying to ${targetName}*\n\n`;
      
      if (recentMessages.length > 0) {
        replyText += '*Recent messages:*\n';
        
        for (const msg of recentMessages) {
          replyText += `- ${msg.text.substring(0, 100)}${msg.text.length > 100 ? '...' : ''}\n`;
          replyText += `  ${msg.createdAt.toISOString().split('T')[0]} ${msg.createdAt.toISOString().split('T')[1].substring(0, 5)}\n\n`;
        }
      }
      
      replyText += 'Please type your reply message or /cancel to abort.';
      
      await ctx.editMessageText(replyText, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [
              { text: 'Cancel', callback_data: 'admin_messages' }
            ]
          ]
        }
      });
    }
    
  } catch (error) {
    logger.error('Error handling message action:', error);
    await ctx.answerCallbackQuery('Failed to perform message action');
  }
}

module.exports = {
  register
};