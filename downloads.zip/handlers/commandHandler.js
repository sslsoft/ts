const User = require('../models/User');
const Setting = require('../models/Setting');
const logger = require('../utils/logger');
const config = require('../config');
const { extractUrlFromText, getPlatformFromUrl } = require('../utils/urlUtils');
const { getKeyboard } = require('../utils/keyboard');

// Command handler registration
function register(bot) {
  // Start command
  bot.start(async (ctx) => {
    try {
      const userId = ctx.from.id;
      const username = ctx.from.username || null;
      const firstName = ctx.from.first_name || '';
      const lastName = ctx.from.last_name || '';
      
      // Find or create user
      let user = await User.findOne({ userId });
      
      if (!user) {
        // Check if the user is an admin based on the configuration
        const isAdmin = config.ADMIN_IDS.includes(userId.toString());
        
        // Create new user
        user = new User({
          userId,
          username,
          firstName,
          lastName,
          isAdmin,
          registeredAt: new Date(),
          lastActive: new Date()
        });
        
        await user.save();
        logger.info(`New user registered: ${userId} (${username || 'no username'})`);
      } else {
        // Update user information
        user.username = username;
        user.firstName = firstName;
        user.lastName = lastName;
        user.lastActive = new Date();
        await user.save();
      }
      
      // Get welcome message from settings
      const welcomeSetting = await Setting.findOne({ key: 'welcomeMessage' });
      const welcomeMessage = welcomeSetting ? welcomeSetting.value : 
        'Welcome to the All-in-One Video Downloader Bot! Send me any video link to download it.';
      
      await ctx.reply(welcomeMessage, {
        parse_mode: 'Markdown',
        reply_markup: getKeyboard(user)
      });
      
    } catch (error) {
      logger.error('Error in start command:', error);
      await ctx.reply('An error occurred while starting the bot. Please try again later.');
    }
  });
  
  // Help command
  bot.command('help', async (ctx) => {
    try {
      const helpMessage = `
*All-in-One Video Downloader Bot Help*

Send me any video URL, and I'll download and send it to you! Supported platforms include YouTube, Instagram, Facebook, Twitter, TikTok, and many others.

*Commands:*
/start - Start the bot
/help - Show this help message
/profile - View your profile and stats
/history - View your download history
/premium - Information about premium features
/contact - Contact the admin for support
/settings - Configure your personal settings

*How to use:*
1. Just send me a link to any video
2. Wait for the bot to process and download the video
3. The video will be sent to you automatically

*Note:* Free users can download ${config.FREE_USER_DAILY_LIMIT} videos per day, while premium users can download ${config.PREMIUM_USER_DAILY_LIMIT} videos per day.
`;
      
      await ctx.reply(helpMessage, {
        parse_mode: 'Markdown'
      });
      
    } catch (error) {
      logger.error('Error in help command:', error);
      await ctx.reply('An error occurred while displaying help. Please try again later.');
    }
  });
  
  // Profile command
  bot.command('profile', async (ctx) => {
    try {
      const userId = ctx.from.id;
      const user = await User.findOne({ userId });
      
      if (!user) {
        return ctx.reply('User not found. Please use /start to register.');
      }
      
      // Get top 3 platforms by download count
      const platformEntries = Array.from(user.platforms.entries());
      platformEntries.sort((a, b) => b[1] - a[1]);
      const topPlatforms = platformEntries.slice(0, 3)
        .map(([platform, count]) => `${platform}: ${count} downloads`)
        .join('\n') || 'No downloads yet';
      
      // Check user's limits
      const limit = user.isPremium ? config.PREMIUM_USER_DAILY_LIMIT : config.FREE_USER_DAILY_LIMIT;
      const remainingToday = Math.max(0, limit - user.dailyDownloads);
      
      const profileMessage = `
*Your Profile*

*User ID:* ${user.userId}
*Username:* ${user.username ? '@' + user.username : 'Not set'}
*Name:* ${user.firstName} ${user.lastName}
*Account Type:* ${user.isPremium ? '⭐ Premium' : '🔹 Free'}
*Role:* ${user.isAdmin ? '👑 Admin' : user.isModerator ? '🛡️ Moderator' : '👤 User'}
*Registered:* ${user.registeredAt.toDateString()}

*Stats:*
*Total Downloads:* ${user.totalDownloads}
*Today's Downloads:* ${user.dailyDownloads}/${limit}
*Remaining Today:* ${remainingToday}

*Top Platforms:*
${topPlatforms}
`;
      
      await ctx.reply(profileMessage, {
        parse_mode: 'Markdown'
      });
      
    } catch (error) {
      logger.error('Error in profile command:', error);
      await ctx.reply('An error occurred while retrieving your profile. Please try again later.');
    }
  });

  // Register other commands
  bot.command('admin', adminCommandHandler);
  bot.command('history', historyCommandHandler);
  bot.command('premium', premiumCommandHandler);
  bot.command('contact', contactCommandHandler);
  bot.command('settings', settingsCommandHandler);
}

// Admin command handler
async function adminCommandHandler(ctx) {
  try {
    const userId = ctx.from.id;
    const user = await User.findOne({ userId });
    
    if (!user || (!user.isAdmin && !user.isModerator)) {
      return ctx.reply('You do not have permission to access the admin panel.');
    }
    
    // Admin panel keyboard
    const adminKeyboard = {
      inline_keyboard: [
        [
          { text: '📊 Statistics', callback_data: 'admin_stats' },
          { text: '👥 User Management', callback_data: 'admin_users' }
        ],
        [
          { text: '🔄 System Status', callback_data: 'admin_system' },
          { text: '⚙️ Bot Settings', callback_data: 'admin_settings' }
        ],
        [
          { text: '📢 Broadcast', callback_data: 'admin_broadcast' },
          { text: '💬 Messages', callback_data: 'admin_messages' }
        ]
      ]
    };
    
    await ctx.reply('*Admin Control Panel*\n\nSelect an option:', {
      parse_mode: 'Markdown',
      reply_markup: adminKeyboard
    });
    
  } catch (error) {
    logger.error('Error in admin command:', error);
    await ctx.reply('An error occurred in the admin panel. Please try again later.');
  }
}

// History command handler
async function historyCommandHandler(ctx) {
  try {
    const userId = ctx.from.id;
    const Download = require('../models/Download');
    
    // Get the 10 most recent downloads
    const downloads = await Download.find({ userId })
      .sort({ createdAt: -1 })
      .limit(10);
    
    if (downloads.length === 0) {
      return ctx.reply('You have no download history yet.');
    }
    
    let historyMessage = '*Your Recent Downloads*\n\n';
    
    downloads.forEach((download, index) => {
      historyMessage += `*${index + 1}.* ${download.title || 'Untitled'}\n`;
      historyMessage += `Platform: ${download.platform}\n`;
      historyMessage += `Status: ${download.status}\n`;
      historyMessage += `Date: ${download.createdAt.toDateString()}\n\n`;
    });
    
    await ctx.reply(historyMessage, {
      parse_mode: 'Markdown'
    });
    
  } catch (error) {
    logger.error('Error in history command:', error);
    await ctx.reply('An error occurred while retrieving your download history. Please try again later.');
  }
}

// Premium command handler
async function premiumCommandHandler(ctx) {
  try {
    const userId = ctx.from.id;
    const user = await User.findOne({ userId });
    
    if (!user) {
      return ctx.reply('User not found. Please use /start to register.');
    }
    
    if (user.isPremium) {
      await ctx.reply(`
*You are already a Premium user!*

Enjoy your premium benefits:
• ${config.PREMIUM_USER_DAILY_LIMIT} downloads per day
• Priority processing
• Access to higher quality downloads
• No wait time between downloads
• Premium support

Thank you for supporting our bot!
      `, {
        parse_mode: 'Markdown'
      });
    } else {
      await ctx.reply(`
*Premium Features*

Upgrade to Premium to enjoy:
• ${config.PREMIUM_USER_DAILY_LIMIT} downloads per day (currently ${config.FREE_USER_DAILY_LIMIT})
• Priority processing
• Access to higher quality downloads
• No wait time between downloads
• Premium support

Contact the admin using /contact to upgrade to Premium.
      `, {
        parse_mode: 'Markdown'
      });
    }
    
  } catch (error) {
    logger.error('Error in premium command:', error);
    await ctx.reply('An error occurred while retrieving premium information. Please try again later.');
  }
}

// Contact command handler
async function contactCommandHandler(ctx) {
  try {
    // Set user state to "waiting_for_contact_message"
    ctx.session = ctx.session || {};
    ctx.session.state = 'waiting_for_contact_message';
    
    await ctx.reply(`
Please enter your message to the admin. 
Be clear and concise with your question or issue.

Type your message or /cancel to abort.
    `);
    
  } catch (error) {
    logger.error('Error in contact command:', error);
    await ctx.reply('An error occurred with the contact form. Please try again later.');
  }
}

// Settings command handler
async function settingsCommandHandler(ctx) {
  try {
    const userId = ctx.from.id;
    const user = await User.findOne({ userId });
    
    if (!user) {
      return ctx.reply('User not found. Please use /start to register.');
    }
    
    const settingsKeyboard = {
      inline_keyboard: [
        [
          { 
            text: `Notifications: ${user.notificationEnabled ? '✅ ON' : '❌ OFF'}`, 
            callback_data: 'toggle_notifications' 
          }
        ],
        [
          { 
            text: 'Change Language', 
            callback_data: 'change_language' 
          }
        ],
        [
          {
            text: 'Done',
            callback_data: 'settings_done'
          }
        ]
      ]
    };
    
    await ctx.reply('*User Settings*\n\nConfigure your personal preferences:', {
      parse_mode: 'Markdown',
      reply_markup: settingsKeyboard
    });
    
  } catch (error) {
    logger.error('Error in settings command:', error);
    await ctx.reply('An error occurred while accessing settings. Please try again later.');
  }
}

module.exports = {
  register
};