const User = require('../models/User');
const Download = require('../models/Download');
const Setting = require('../models/Setting');
const Message = require('../models/Message');
const logger = require('../utils/logger');
const config = require('../config');

// Admin handler registration
function register(bot) {
  // Handler for admin text messages (not command related)
  bot.hears(/.*/, async (ctx, next) => {
    try {
      // Check if the user is in an admin-specific state
      if (!ctx.session || !ctx.session.state || !ctx.session.state.startsWith('admin_')) {
        // Not in admin state, proceed to next middleware
        return next();
      }
      
      const userId = ctx.from.id;
      const user = await User.findOne({ userId });
      
      if (!user || (!user.isAdmin && !user.isModerator)) {
        // Not an admin or moderator, proceed to next middleware
        return next();
      }
      
      const text = ctx.message.text;
      
      // Handle different admin states
      if (ctx.session.state === 'admin_updating_limit_free') {
        await handleUpdateFreeLimit(ctx, user, text);
      } else if (ctx.session.state === 'admin_updating_limit_premium') {
        await handleUpdatePremiumLimit(ctx, user, text);
      } else if (ctx.session.state === 'admin_updating_api_key') {
        await handleUpdateApiKey(ctx, user, text);
      } else if (ctx.session.state === 'admin_updating_api_url') {
        await handleUpdateApiUrl(ctx, user, text);
      } else if (ctx.session.state === 'admin_updating_welcome') {
        await handleUpdateWelcomeMessage(ctx, user, text);
      } else if (ctx.session.state === 'admin_broadcast') {
        await handleBroadcastMessage(ctx, user, text);
      } else {
        // Unknown admin state, proceed to next middleware
        return next();
      }
      
    } catch (error) {
      logger.error('Error in admin handler:', error);
      await ctx.reply('An error occurred while processing your admin request.');
      return next();
    }
  });
}

// Handle updating free user daily limit
async function handleUpdateFreeLimit(ctx, user, text) {
  try {
    // Parse the new limit value
    const newLimit = parseInt(text);
    
    if (isNaN(newLimit) || newLimit < 1) {
      return ctx.reply('Please enter a valid number greater than 0.');
    }
    
    // Update the setting
    await Setting.updateOne(
      { key: 'freeUserDailyLimit' },
      { $set: { value: newLimit, updatedBy: user.userId, updatedAt: new Date() } },
      { upsert: true }
    );
    
    // Update config
    config.FREE_USER_DAILY_LIMIT = newLimit;
    
    // Clear the session state
    delete ctx.session.state;
    
    await ctx.reply(`Free user daily limit updated to ${newLimit}.`);
    
  } catch (error) {
    logger.error('Error updating free user limit:', error);
    await ctx.reply('Failed to update free user limit. Please try again.');
  }
}

// Handle updating premium user daily limit
async function handleUpdatePremiumLimit(ctx, user, text) {
  try {
    // Parse the new limit value
    const newLimit = parseInt(text);
    
    if (isNaN(newLimit) || newLimit < 1) {
      return ctx.reply('Please enter a valid number greater than 0.');
    }
    
    // Update the setting
    await Setting.updateOne(
      { key: 'premiumUserDailyLimit' },
      { $set: { value: newLimit, updatedBy: user.userId, updatedAt: new Date() } },
      { upsert: true }
    );
    
    // Update config
    config.PREMIUM_USER_DAILY_LIMIT = newLimit;
    
    // Clear the session state
    delete ctx.session.state;
    
    await ctx.reply(`Premium user daily limit updated to ${newLimit}.`);
    
  } catch (error) {
    logger.error('Error updating premium user limit:', error);
    await ctx.reply('Failed to update premium user limit. Please try again.');
  }
}

// Handle updating API key
async function handleUpdateApiKey(ctx, user, text) {
  try {
    const newApiKey = text.trim();
    
    if (!newApiKey) {
      return ctx.reply('Please enter a valid API key.');
    }
    
    // Update the setting
    await Setting.updateOne(
      { key: 'apiKey' },
      { $set: { value: newApiKey, updatedBy: user.userId, updatedAt: new Date() } },
      { upsert: true }
    );
    
    // Update config
    config.VIDEO_API_KEY = newApiKey;
    
    // Clear the session state
    delete ctx.session.state;
    
    await ctx.reply('API key updated successfully.');
    
  } catch (error) {
    logger.error('Error updating API key:', error);
    await ctx.reply('Failed to update API key. Please try again.');
  }
}

// Handle updating API URL
async function handleUpdateApiUrl(ctx, user, text) {
  try {
    const newApiUrl = text.trim();
    
    if (!newApiUrl) {
      return ctx.reply('Please enter a valid API URL.');
    }
    
    // Update the setting
    await Setting.updateOne(
      { key: 'apiUrl' },
      { $set: { value: newApiUrl, updatedBy: user.userId, updatedAt: new Date() } },
      { upsert: true }
    );
    
    // Update config
    config.VIDEO_API_URL = newApiUrl;
    
    // Clear the session state
    delete ctx.session.state;
    
    await ctx.reply('API URL updated successfully.');
    
  } catch (error) {
    logger.error('Error updating API URL:', error);
    await ctx.reply('Failed to update API URL. Please try again.');
  }
}

// Handle updating welcome message
async function handleUpdateWelcomeMessage(ctx, user, text) {
  try {
    const newWelcomeMessage = text.trim();
    
    if (!newWelcomeMessage) {
      return ctx.reply('Please enter a valid welcome message.');
    }
    
    // Update the setting
    await Setting.updateOne(
      { key: 'welcomeMessage' },
      { $set: { value: newWelcomeMessage, updatedBy: user.userId, updatedAt: new Date() } },
      { upsert: true }
    );
    
    // Clear the session state
    delete ctx.session.state;
    
    await ctx.reply('Welcome message updated successfully.');
    
  } catch (error) {
    logger.error('Error updating welcome message:', error);
    await ctx.reply('Failed to update welcome message. Please try again.');
  }
}

// Handle broadcast message
async function handleBroadcastMessage(ctx, user, text) {
  try {
    // Store the broadcast message in the session
    ctx.session.broadcastMessage = text;
    
    // Clear the state and set up for target selection
    delete ctx.session.state;
    
    // Show target selection options
    const broadcastKeyboard = {
      inline_keyboard: [
        [
          { text: 'All Users', callback_data: 'admin_broadcast_all' },
          { text: 'Premium Users', callback_data: 'admin_broadcast_premium' }
        ],
        [
          { text: 'Free Users', callback_data: 'admin_broadcast_free' },
          { text: 'Active Users (24h)', callback_data: 'admin_broadcast_active' }
        ],
        [
          { text: 'Cancel', callback_data: 'admin_cancel_broadcast' }
        ]
      ]
    };
    
    await ctx.reply(`
*Broadcast Message Preview:*

${text}

Select the target audience for this message:
    `, {
      parse_mode: 'Markdown',
      reply_markup: broadcastKeyboard
    });
    
  } catch (error) {
    logger.error('Error handling broadcast message:', error);
    await ctx.reply('Failed to process broadcast message. Please try again.');
  }
}

module.exports = {
  register
};